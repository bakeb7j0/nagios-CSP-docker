#!/bin/bash

if [ `command -v yum` ]; then
	yum install 'perl(Date::Parse)' -y
else
	cpan install Date::Parse ||:
fi
exit 0
