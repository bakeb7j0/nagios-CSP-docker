    <input type="hidden" id="selectedhostconfig" name="selectedhostconfig" value="<?= encode_form_val($selectedhostconfig) ?>" />
    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

    <div class="container m-0 g-0">
<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
        <!--                         -->
        <!-- The configuration form. -->
        <!--                         -->
        <div id="configForm">
    <h5 class="ul"><?= _('Domain Name') ?></h5>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="domain_name" class="form-label form-item-required"><?= _('FQDN') ?> <?= xi6_info_tooltip(_('The fully qualified domain name you would like to monitor')) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="domain_name" id="domain_name" value="<?= encode_form_val($address) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter FQDN") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the FQDN
                        </div>
                        <i id="domain_name_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

        </div> <!-- config -->
    </div> <!-- container -->

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
