    <!--                                   -->
    <!-- The initial data set from Step 1. -->
    <!--                                   -->
    <input type="hidden" id="hostname" name="hostname" value="<?= encode_form_val($hostname) ?>">
    <input type="hidden" id="operation" name="operation" value="<?= encode_form_val($operation) ?>">
    <input type="hidden" id="selectedhostconfig" name="selectedhostconfig" value="<?= encode_form_val($selectedhostconfig) ?>">
    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

    <input type="hidden" name="ip_address" value="<?= encode_form_val($address) ?>">
<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
    <div class="container-fluid m-0 g-0">

        <h2 class="mb-2"><?= _('Host Details') ?></h2>

        <div class="row mb-2">
            <div class="col-sm-6">
                <label for="ip_address" class="form-label"><?= _('IP Address') ?> </label>
                <div class="input-group position-relative">
                    <input type="text" name="ip_address" id="ip_address" value="<?= encode_form_val($address) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter IP Address") ?>" disabled="on">
                    <div class="invalid-feedback">
                        <?= _("Please enter the IP Address") ?>
                    </div>
                    <i id="ip_address_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>

        <div class="row mb-2">
            <div class="col-sm-6">
                <label for="hostname" class="form-label"><?= _('Host Name') ?> <?= xi6_info_tooltip(_('The name you would like to have associated with this Windows system')) ?></label>
                <div class="input-group position-relative">
                    <input type="text" name="hostname" id="hostname" value="<?= encode_form_val($hostname) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter Host Name") ?>" >
                    <div class="invalid-feedback">
                        <?= _("Please enter the Host Name") ?>
                    </div>
                    <i id="hostname_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>

        <h2 class="mt-4"><?= _('NSClient++ Agent') ?></h2>
        <p class="w-50"><?= _('You will need to install an agent on the Windows system in order to monitor it. For security purposes, it is recommended to use a password with the agent') ?></p>

        <div class="alert alert-info w-75">
            <?= _("This config wizard is <b>deprecated</b>. We recommend using the") ?> <a href="monitoringwizard.php?wizard=windowsserver&nextstep=2&nsp=<?= get_nagios_session_protector_id() ?>"><?= _("Windows Server")."</a> "._("or") ?> <a href="monitoringwizard.php?wizard=windowsdesktop&nextstep=2&nsp=<?= get_nagios_session_protector_id() ?>"><?= _("Windows Desktop")."</a> "._("configuration wizard instead.") ?>
        </div>

        <div class="row mb-6 mt-4 mb-2">
            <label class="bold"><?= _('Agent Downloads') ?></label>
        </div>
        <div class="row mb-6">
            <div class="col-sm-3">
                <label class="form-check-label bold"><?= _('32-Bit Agent') ?></label>
            </div>
            <div class="col-sm-3">
                <label class="form-check-label bold"><?= _('64-Bit Agent') ?></label>
            </div>
        </div>
        <div class="row mb-6">
            <div class="col-sm-3">
                <label>
                    <a href="<?= $agent32_stable_url ?>"><i class="material-symbols-outlined md-20 md-400 md-action md-middle">download</i></a> <a href="<?= $agent32_stable_url ?>"><?= _('Download') ?> v0.4.4 (32bit)</a>
                </label>
            </div>
            <div class="col-sm-3">
                <label>
                    <a href="<?= $agent64_stable_url ?>"><i class="material-symbols-outlined md-20 md-400 md-action md-middle">download</i></a> <a href="<?= $agent64_stable_url ?>"><?= _('Download') ?> v0.4.4 (64bit)</a>
                </label>
            </div>
        </div>

        <div class="row mb-2 mt-4">
            <div class="col-sm-6">
                <label for="password" class="form-label"><?= _('Agent Password') ?> <?= xi6_info_tooltip(_('Valid characters include').': a-zA-Z0-9 .\:_-@') ?></label>
                <div class="input-group position-relative">
                    <input type="text" name="password" id="password" value="<?= encode_form_val($password) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter Agent Password") ?>" >
                    <div class="invalid-feedback">
                        <?= _("Please enter the Password") ?>
                    </div>
                    <i id="password_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>


        <!--                         -->
        <!-- The metrics to monitor. -->
        <!--                         -->
        <h2 class="mt-4"><?= _('Server Metrics') ?></h2>
        <p><?= _('Specify which services you would like to monitor for the system') ?>.</p>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm mt-0 pt-1">
                        <input type="checkbox" id="p" class="form-check-input" name="services[ping]"  <?= is_checked(checkbox_binary($services['ping']), "1") ?> >
                        <label for="p" class="form-check-label bold"><?= _('Ping') ?> <?= xi6_info_tooltip(_("Monitors the server with an ICMP ping. Useful for watching network latency and general uptime")) ?></label>
                    </div>
                </fieldset>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-1">
                        <input type="checkbox" id="cpu" class="form-check-input" name="services[cpu]"  <?= is_checked(checkbox_binary($services['cpu']), "1") ?> >
                        <label for="cpu" class="form-check-label bold"><?= _('CPU') ?> <?= xi6_info_tooltip(_("Monitors the CPU (processor usage) on the server")) ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                            </span>
                            <input type="text" id="serviceargs[cpu_warning]" name="serviceargs[cpu_warning]" value="<?= encode_form_val($serviceargs['cpu_warning']) ?>" class="form-control form-control-sm monitor">
                            <span class="input-group-text">%</span>
                            <i id="serviceargs_cpu_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400 md-middle">error</i>
                            </span>
                            <input type="text" id="serviceargs[cpu_critical]" name="serviceargs[cpu_critical]" value="<?= encode_form_val($serviceargs['cpu_critical']) ?>" class="form-control form-control-sm monitor">
                            <span class="input-group-text">%</span>
                            <i id="serviceargs_cpu_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-1">
                        <input type="checkbox" id="mu" class="form-check-input" name="services[memory]"  <?= is_checked(checkbox_binary($services['memory']), "1") ?> >
                        <label for="mu" class="form-check-label bold"><?= _('Memory Usage') ?> <?= xi6_info_tooltip(_("Monitors the memory usage on the server")) ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                            </span>
                            <input type="text" id="" name="" value="" class="form-control form-control-sm monitor">
                            <span class="input-group-text">%</span>
                            <i id="" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400 md-middle">error</i>
                            </span>
                            <input type="text" id="serviceargs[memory_critical]" name="serviceargs[memory_critical]" value="<?= encode_form_val($serviceargs['memory_critical']) ?>" class="form-control form-control-sm monitor">
                            <span class="input-group-text">%</span>
                            <i id="serviceargs_memory_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm mt-0 pt-1">
                        <input type="checkbox" id="up" class="form-check-input" name="services[uptime]"  <?= is_checked(checkbox_binary($services['uptime']), "1") ?> >
                        <label for="up" class="form-check-label bold"><?= _('Uptime') ?> <?= xi6_info_tooltip(_("Monitors the uptime on the server")) ?></label>
                    </div>
                </fieldset>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm mt-0 pt-1">
                        <input type="checkbox" id="du" class="form-check-input" name="services[disk]"  <?= is_checked(checkbox_binary($services['disk']), "1") ?> >
                        <label for="du" class="form-check-label bold"><?= _('Disk Usage') ?> <?= xi6_info_tooltip(_("Monitors disk usage on the server")) ?></label>
                    </div>
                </fieldset>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2">
                    <div class="form-check col-sm-3 mt-0">
                        <label class="form-check-label bold"><?= _('Drive') ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <label class="form-check-label bold"><?= _('Warning') ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <label class="form-check-label bold"><?= _('Critical') ?></label>
                    </div>
                </fieldset>
            </div>
        </div>

        <div id="diskCriticalListDiv">
            <div class="adddeleterow diskCriticalList">
<?php
    for ($x = 0; $x < count($serviceargs["disk"]); $x++) {
        $checkedstr = "";

        if ($x == 0) {
            $checkedstr = "checked";
        }
?>
                <div class="row">
                    <div class="col-sm-8">
                        <fieldset class="row g-2 mb-1 wz-fieldset">
                            <div class="form-check col-sm-3 mt-0">
                                <select name="serviceargs[disk][<?= $x ?>]" class="form-control form-control-sm form-select form-select-sm">
                                    <option value=""></option>
<?php
        for ($y = 0; $y < 26; $y++) {
            $selected = "";
            $diskname = chr(ord('A') + $y);
            $selected = is_selected($serviceargs["disk"][$x], $diskname);
?>
                                    <option value="<?= $diskname ?>" <?= $selected ?>><?= $diskname ?>:</option>
<?php
        }
?>
                                </select>
                            </div>
                            <div class="col-sm-3 mt-0">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text">
                                        <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                                    </span>
                                    <input type="text" id="serviceargs[disk_warning][<?= $x ?>]" name="serviceargs[disk_warning][<?= $x ?>]" value="<?= encode_form_val($serviceargs['disk_warning'][$x]) ?>" class="form-control form-control-sm monitor">
                                    <span class="input-group-text">%</span>
                                    <i id="serviceargs_disk_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                                </div>
                            </div>
                            <div class="col-sm-3 mt-0">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text">
                                        <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400 md-middle">error</i>
                                    </span>
                                    <input type="text" id="serviceargs[disk_critical][<?= $x ?>]" name="serviceargs[disk_critical][<?= $x ?>]" value="<?= encode_form_val($serviceargs['disk_critical'][$x]) ?>" class="form-control form-control-sm monitor">
                                    <span class="input-group-text">%</span>
                                    <i id="serviceargs_disk_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
<?php
    }
?>
            </div> <!-- adddeleterow diskCriticalList -->
        </div> <!-- diskCriticalListDiv -->

        <h2 class="mt-4"><?= _('Services') ?></h2>
        <p><?= _('Specify any services that should be monitored to ensure they are in a running state') ?>.</p>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2">
                    <div class="form-check col-sm-5 mt-0">
                        <label class="form-check-label bold"><?= _('Windows Service') ?></label>
                    </div>
                    <div class="col-sm-5 mt-0">
                        <label class="form-check-label bold"><?= _('Display Name') ?></label>
                    </div>
                </fieldset>
            </div>
        </div>

        <div id="serviceStateListDiv">
            <div class="adddeleterow serviceStateList">
<?php
    for ($x = 0; $x < count($serviceargs['servicestate']); $x++) {
        $servicestring = encode_form_val($serviceargs['servicestate'][$x]['service']);
        $servicename = encode_form_val($serviceargs['servicestate'][$x]['name']);
        $is_checked = isset($services['servicestate'][$x]) ? is_checked($services['servicestate'][$x]) : '';
?>
                 <div class="row">
                    <div class="col-sm-8">
                        <fieldset class="row g-2 mb-1 wz-fieldset">
                            <div class="form-check col-sm-5 mt-0">
                                <div class="input-group input-group-sm">
                                    <input type="checkbox" class="form-check-input mt-2 me-2" name="services[servicestate][<?= $x ?>]" <?= $is_checked ?>>
                                    <input type="text" name="serviceargs[servicestate][<?= $x ?>][service]" id="serviceargs[servicestate][<?= $x ?>][service]" value="<?= $servicestring ?>" class="form-control form-control-sm rounded monitor">
                                    <i id="serviceargs_servicestate_<?= $x ?>_service_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                                </div>
                            </div>
                            <div class="col-sm-5 mt-0">
                                <input type="text" name="serviceargs[servicestate][<?= $x ?>][name]" id="serviceargs[servicestate][<?= $x ?>][name]" value="<?= $servicename ?>" class="form-control form-control-sm rounded monitor">
                                <i id="serviceargs_servicestate_<?= $x ?>_name_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </fieldset>
                    </div>
                </div>
<?php
    }
?>
            </div> <!-- adddeleterow serviceStateList -->
        </div> <!-- serviceStateListDiv -->

        <h2 class="mt-4"><?= _('Processes') ?></h2>
        <p><?= _('Specify any processes that should be monitored to ensure they are running') ?>.</p>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2">
                    <div class="form-check col-sm-5 mt-0">
                        <label class="form-check-label bold"><?= _('Windows Service') ?></label>
                    </div>
                    <div class="col-sm-5 mt-0">
                        <label class="form-check-label bold"><?= _('Display Name') ?></label>
                    </div>
                </fieldset>
            </div>
        </div>

        <div id="processStateListDiv">
            <div class="adddeleterow processStateList">
<?php
    for ($x = 0; $x < count($serviceargs['processstate']); $x++) {
        $processstring = encode_form_val($serviceargs['processstate'][$x]['process']);
        $processname = encode_form_val($serviceargs['processstate'][$x]['name']);
        $is_checked = isset($services['processstate'][$x]) ? is_checked($services['processstate'][$x]) : '';
?>
                 <div class="row">
                    <div class="col-sm-8">
                        <fieldset class="row g-2 mb-1 wz-fieldset">
                            <div class="form-check col-sm-5 mt-0">
                                <div class="input-group input-group-sm">
                                    <input type="checkbox" class="form-check-input mt-2 me-2" name="services[processstate][<?= $x ?>]" <?= $is_checked ?>>
                                    <input type="text" name="serviceargs[processstate][<?= $x ?>][process]" id="serviceargs[processstate][<?= $x ?>][process]" value="<?= $processstring ?>" class="form-control form-control-sm rounded monitor">
                                    <i id="serviceargs_processstate_<?= $x ?>_service_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                                </div>
                            </div>
                            <div class="col-sm-5 mt-0">
                                <input type="text" name="serviceargs[processstate][<?= $x ?>][name]" id="serviceargs[processstate][<?= $x ?>][name]" value="<?= $processname ?>" class="form-control form-control-sm rounded monitor">
                                <i id="serviceargs_processstate_<?= $x ?>_name_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </fieldset>
                    </div>
                </div>
<?php
    }
?>
            </div> <!-- adddeleterow processStateList -->
        </div> <!-- processStateListDiv -->

        <h2 class="mt-4"><?= _('Performance Counters') ?></h2>
        <p><?= _('Specify any performance counters that should be monitored') ?>.</p>

        <div class="row">
            <div class="col-sm-12">
                <fieldset class="row g-2">
                    <div class="form-check col-sm-3">
                        <label class="form-check-label bold"><?= _('Performance Counter') ?></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><?= _('Display Name') ?></label>
                    </div>
                    <div class="col-sm-4">
                        <label class="form-check-label bold"><?= _('Counter Output Format') ?></label>
                    </div>
                    <div class="col-sm-1">
                        <label class="form-check-label bold"><?= _('Warning') ?></label>
                    </div>
                    <div class="col-sm-1">
                        <label class="form-check-label bold"><?= _('Critical') ?></label>
                    </div>
                </fieldset>
            </div>
        </div>

        <div id="performanceDiv">
            <div class="adddeleterow performanceCountersList">
<?php
    for ($x = 0; $x < count($serviceargs['counter']); $x++) {
        $counterstring = encode_form_val($serviceargs['counter'][$x]['counter']);
        $countername = encode_form_val($serviceargs['counter'][$x]['name']);
        $counterformat = encode_form_val($serviceargs['counter'][$x]['format']);
        $warnlevel = encode_form_val($serviceargs['counter'][$x]['warning']);
        $critlevel = encode_form_val($serviceargs['counter'][$x]['critical']);
        $is_checked = isset($services['counter'][$x]) ? is_checked($services['counter'][$x]) : '';
?>
                 <div class="row">
                    <div class="col-sm-12">
                        <fieldset class="row g-2 mb-1 wz-fieldset">
                            <div class="form-check col-sm-3 mt-0">
                                <div class="input-group input-group-sm">
                                    <input type="checkbox" class="form-check-input mt-2 me-2" name="services[counter][<?= $x ?>]" <?= $is_checked ?>>
                                    <input type="text" name="serviceargs[counter][<?= $x ?>][counter]" id="serviceargs[counter][<?= $x ?>][counter]" value="<?= $counterstring ?>" class="form-control form-control-sm rounded monitor">
                                    <i id="serviceargs_counter_<?= $x ?>_counter_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                                </div>
                            </div>
                            <div class="col-sm-3 mt-0">
                                <input type="text" name="serviceargs[counter][<?= $x ?>][name]" id="serviceargs[counter][<?= $x ?>][name]" value="<?= $countername ?>" class="form-control form-control-sm rounded monitor">
                                <i id="serviceargs_counter_<?= $x ?>_name_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                            <div class="col-sm-4 mt-0">
                                <input type="text" name="serviceargs[counter][<?= $x ?>][format]" id="serviceargs[counter][<?= $x ?>][format]" value="<?= $counterformat ?>" class="form-control form-control-sm rounded monitor">
                                <i id="serviceargs_counter_<?= $x ?>_format_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                            <div class="col-sm-1 mt-0">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text p-1">
                                        <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                                    </span>
                                    <input type="text" id="serviceargs[counter][<?= $x ?>][warning]" name="serviceargs[counter][<?= $x ?>][warning]" value="<?= $warnlevel ?>" class="form-control form-control-sm monitor">
                                    <i id="serviceargs_counter_<?= $x ?>_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                                </div>
                            </div>
                            <div class="col-sm-1 mt-0">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text p-1">
                                        <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400 md-middle">error</i>
                                    </span>
                                    <input type="text" id="serviceargs[counter][<?= $x ?>][critical]" name="serviceargs[counter][<?= $x ?>][critical]" value="<?= $critlevel ?>" class="form-control form-control-sm monitor">
                                    <i id="serviceargs_counter_<?= $x ?>_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
<?php
    }
?>
            </div> <!-- adddeleterow performanceCountersList -->
        </div> <!-- performanceDiv -->

    </div> <!-- container -->

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
