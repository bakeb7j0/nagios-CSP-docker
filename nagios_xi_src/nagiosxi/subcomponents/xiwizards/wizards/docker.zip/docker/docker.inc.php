<?php
//
// Docker Config Wizard
// Copyright (c) 2018-2024 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

docker_configwizard_init();

function docker_configwizard_init()
{
    $name = 'docker';
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _('Monitor Docker containers via NCPA or through the cURL API.'),
        CONFIGWIZARD_DISPLAYTITLE => _('Docker'),
        CONFIGWIZARD_FUNCTION => 'docker_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'docker.png',
        CONFIGWIZARD_VERSION => '2.0.4',
        CONFIGWIZARD_COPYRIGHT => _("Copyright &copy; 2017-2024 Nagios Enterprises, LLC."),
        CONFIGWIZARD_AUTHOR => _('Nagios Enterprises, LLC.'),
        CONFIGWIZARD_FILTER_GROUPS => array('server'),
        CONFIGWIZARD_REQUIRES_VERSION => 60100
    );
    register_configwizard($name,$args);
}

// This function is automatically called by the XI wizard framework when the wizard is run
function docker_configwizard_func($mode = '', $inargs = null, &$outargs = null, &$result = null)
{
    $wizard_name = 'docker';

    /* Prerequisite software */
    $NCPA_download_url = "https://www.nagios.org/ncpa/#downloads";
    $NCPA_docs_url = "https://www.nagios.org/ncpa/#docs";
    $docker_plugin_url = "/nagiosxi/includes/configwizards/docker/plugins/check_docker.py";
    $docker_docs_url = "https://assets.nagios.com/downloads/nagiosxi/docs/How-to-Monitor-Docker-Containers-with-Nagios-XI.pdf";

    /* Initialize return code and output */
    $result = 0;
    $output = '';

    /* Initialize output args */
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            /* This defines $nextstep variable, used for determining if the user did not */
            /* provide correct information when the user was on CONFIGWIZARD_MODE_GETSTAGE1HTML */
            $nextstep = encode_form_val(grab_array_var($_POST, 'nextstep',false),ENT_QUOTES);

            /* Determine if this is the first wizard run */
            if ($nextstep == '') {
                /* Clear the session array to be sure it is blank */
                unset($_SESSION[$wizard_name]);
            }

            /* Fresh Wizard Run */
            /* OR */
            /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE1DATA due to user error */

            if (!isset($_POST['ip_address'])) {
                /* Fresh Wizard Run */

                /* Define the session array to hold data from different stages */
                $_SESSION[$wizard_name] = array();

                /* The following variables need to be defined to prevent coding errors */
                $address = '';
                $socket = '';
                $baseurl = '';
                $port = '5693';
                $token = '';

                $list_type = "none";
                $container_names = array();
                $network_names = array();
                $check_types = array('exist' => '0', 'running' => '0', 'healthy' => '0', 'cpu' => '0', 'memory' => '0');

                $remote = '';

                $exist = '';
                $running = '';
                $healthy = '';
                $cpu = '';
                $memory = '';

                $cert = '';
                $key = '';
                $cacert = '';

            } else {
                /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE1DATA due to user error */

                /* Grab user data already provided from CONFIGWIZARD_MODE_GETSTAGE1HTML */
                /* Prioritize _SESSION, but use inargs if _SESSION is unset. */
                $remote_session = grab_array_var($_SESSION[$wizard_name], 'remote', ''); // only used in the next line
                $remote = grab_array_var($inargs, 'remote', $remote_session);
                $address_session = grab_array_var($_SESSION[$wizard_name], 'ip_address', '');
                $address = grab_array_var($inargs, 'ip_address', $address_session);
                $socket_session = grab_array_var($_SESSION[$wizard_name], 'socket', '');
                $socket = grab_array_var($inargs, 'socket', $socket_session);
                $baseurl_session = grab_array_var($_SESSION[$wizard_name], 'baseurl', '');
                $baseurl = grab_array_var($inargs, 'baseurl', $baseurl_session);
                $port_session = grab_array_var($_SESSION[$wizard_name], 'port', '5693');
                $port = grab_array_var($inargs, 'port', $port_session);
                $token_session = grab_array_var($_SESSION[$wizard_name], 'token', '');
                $token = grab_array_var($inargs, 'token', $port_session);

                $list_type_session = grab_array_var($_SESSION[$wizard_name], 'list_type', '');
                $list_type = grab_array_var($inargs, 'list-type',$list_type_session);

                $container_names_session = grab_array_var($_SESSION[$wizard_name], 'container_names', array());
                $container_names = grab_array_var($inargs, 'containernames', $container_names_session);
                $container_names = array_values(array_filter($container_names));

                $network_names_session = grab_array_var($_SESSION[$wizard_name], 'network_names', array());
                $network_names = grab_array_var($inargs, 'networknames', $network_names_session);
                $network_names = array_values(array_filter($network_names));

                $check_types_session = grab_array_var($_SESSION[$wizard_name], 'check_types', array());
                $check_types = grab_array_var($inargs, 'checktype', $check_types_session);

                $cert_session = grab_array_var($_SESSION[$wizard_name], 'cert', '');
                $cert = grab_array_var($inargs, 'cert', $cert_session);
                $key_session = grab_array_var($_SESSION[$wizard_name], 'key', '');
                $key = grab_array_var($inargs, 'key', $key_session);
                $cacert_session = grab_array_var($_SESSION[$wizard_name], 'cacert', '');
                $cacert = grab_array_var($inargs, 'cacert', $cacert_session);
            }

            # Get the existing host/node configurations.
            # TODO: Include passwords/secrets?
            $nodes = get_configwizard_hosts($wizard_name);

            ########################################################################################
            # Load the html
            # - The html needs to end up in the $output string, so use ob_start() and ob_get_clean()
            #   to load the PHP from the Step1 file into the $output string.
            ########################################################################################
            ob_start();
            include __DIR__.'/steps/step1.php';
            $output = ob_get_clean();

            break;


        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE1HTML */
        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE2HTML */
            $back = array_key_exists("backButton", $_POST);

            /* If the user came back from CONFIGWIZARD_MODE_GETSTAGE3HTML then we don't need to revalidate and check for errors */
            if ($back) {
                break;
            }

            /* Get variables that were passed to us */
                /* NOTE: grab_array_var is an XI wrapper function to fetch values 'if they exist' */
                /* USAGE: grab_array_var($array, $variable, $defaultValue) */
            $remote_session = grab_array_var($_SESSION[$wizard_name], 'remote', ''); // only used in the next line
            $remote = grab_array_var($inargs, 'remote', $remote_session);
            $address_session = grab_array_var($_SESSION[$wizard_name], 'ip_address', '');
            $address = grab_array_var($inargs, 'ip_address',$address_session);
            $socket_session = grab_array_var($_SESSION[$wizard_name], 'socket', '');
            $socket = grab_array_var($inargs, 'socket',$socket_session);
            $baseurl_session = grab_array_var($_SESSION[$wizard_name], 'baseurl', '');
            $baseurl = grab_array_var($inargs, 'baseurl',$baseurl_session);

            $port_session = grab_array_var($_SESSION[$wizard_name], 'port', '');
            $port = grab_array_var($inargs, 'port', $port_session);
            $port = intval($port);
            $token_session = grab_array_var($_SESSION[$wizard_name], 'token', '');
            $token = grab_array_var($inargs, 'token', $token_session);

            $list_type_session = grab_array_var($_SESSION, 'list_type', '');
            $list_type = grab_array_var($inargs, 'list-type',$list_type_session);

            $container_names_session = grab_array_var($_SESSION, 'container_names', array());
            $container_names = grab_array_var($inargs, 'containernames', $container_names_session);
            $container_names = array_values(array_filter($container_names));

            $network_names_session = grab_array_var($_SESSION, 'network_names', array());
            $network_names = grab_array_var($inargs, 'networknames', $network_names_session);
            $network_names = array_values(array_filter($network_names));

            $check_types_session = grab_array_var($_SESSION, 'check_type', array());
            $check_types = grab_array_var($inargs, 'checktype', $check_types_session);

            $cert_session = grab_array_var($_SESSION[$wizard_name], 'cert', '');
            $cert = grab_array_var($inargs, 'cert', $cert_session);
            $key_session = grab_array_var($_SESSION[$wizard_name], 'key', '');
            $key = grab_array_var($inargs, 'key', $key_session);
            $cacert_session = grab_array_var($_SESSION[$wizard_name], 'cacert', '');
            $cacert = grab_array_var($inargs, 'cacert', $cacert_session);

            /* Now lets check for errors before proceeding to CONFIGWIZARD_MODE_GETSTAGE2HTML*/
            /* Set the error count to 0 */
            $errors = 0;
            /* Create the error messages array */
            $errmsg = array();

            /* Check to see if the address field was blank */
            if (have_value($address) == false) {
                /* address field was blank, add an error message to the array and increment the $errors count */
                $errmsg[$errors++] = _('No address specified.');
            }

            if (have_value($baseurl) == false) {
                $errmsg[$errors++] = _('No Docker API base URL specified.');
            }

            if ($remote === "NCPA") {
                $ncpa_full_url = "https://" . $address . ":" . $port . "/api/plugins?token=" . $token;
                $cmd = '';
                $result = ncpa_plugin_check($ncpa_full_url, $cmd); // defined at end of file

                if ($result > 0) {
                    if ($result === 1) {
                        $errmsg[$errors++] = _("cURL call to verify NCPA installation failed.");

                    } else if ($result === 2) {
                        $errmsg[$errors++] = _("cURL call to NCPA port did not return JSON data.");

                    } else if ($result === 3) {
                        $errmsg[$errors++] = _("cURL call to NCPA port returned invalid JSON.");

                    } else if ($result === 4) {
                        $errmsg[$errors++] = _("check_docker.py not installed on remote machine.");

                    } else {
                        $errmsg[$errors++] = _("cURL-related error: $result");
                    }
                }
            }

            $valid_list_types = array("networks", "containers", "all");

            if (empty($check_types)) {
                $errmsg[$errors++] = _('No check types specified.');
            }

            if ($list_type === "none") {
                $errmsg[$errors++] = _('Please choose a way to monitor your containers.');

            } else if (!in_array($list_type, $valid_list_types)) {
                $errmsg[$errors++] = _('Invalid container list type.');

            } else if ($list_type === "containers") {
                if (empty($container_names)) {
                    $errmsg[$errors++] = _('No containers specified.');
                }
            } else if ($list_type === "networks") {
                if (empty($network_names)) {
                    $errmsg[$errors++] = _('No networks specified.');
                }
            }

            /* Check to see if the $errors array contains errors */
            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;

            } else {
                $_SESSION[$wizard_name]['ip_address'] = $address;
                $_SESSION[$wizard_name]['socket'] = $socket;
                $_SESSION[$wizard_name]['baseurl'] = $baseurl;
                $_SESSION[$wizard_name]['port'] = $port;
                $_SESSION[$wizard_name]['token'] = $token;
                $_SESSION[$wizard_name]['list_type'] = $list_type;
                $_SESSION[$wizard_name]['container_names'] = $container_names;
                $_SESSION[$wizard_name]['network_names'] = $network_names;
                $_SESSION[$wizard_name]['check_types'] = $check_types;
                $_SESSION[$wizard_name]['remote'] = $remote;
                $_SESSION[$wizard_name]['cert'] = $cert;
                $_SESSION[$wizard_name]['key'] = $key;
                $_SESSION[$wizard_name]['cacert'] = $cacert;
            }

            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE1DATA */
            break;



        case CONFIGWIZARD_MODE_GETSTAGE2HTML:
            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE3HTML */
            $back = encode_form_val(grab_array_var($_POST, 'backButton', false), ENT_QUOTES);

            /* Continuing from CONFIGWIZARD_MODE_GETSTAGE1HTML */
            /* OR */
            /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE2DATA due to user error */

            if (isset($_POST['ip_address'])) {
                /* Continuing from CONFIGWIZARD_MODE_GETSTAGE1HTML */
                /* The following line can be enabled for debugging purposes */
                //print_r('<br />Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE1DATA<br />');

                /* Grab array variables from CONFIGWIZARD_MODE_GETSTAGE1HTML */
                $address = grab_array_var($inargs, 'ip_address', '');

                /* We will save these to the session variable array for later use */
                $_SESSION[$wizard_name]['ip_address'] = $address;

                /* The following function queries DNS using $addess to see if it can determine a FQDN for the object */
                /* Obviously this is more relevant when the user provided an IP Address on CONFIGWIZARD_MODE_GETSTAGE1HTML */
                $hostname = gethostbyaddr($address);

                /* The following variables need to be defined to prevent coding errors */
                $list_type = "none";
                $container_names = array();
                $network_names = array();
                $check_types = array();

            } else {
                /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE2DATA due to user error */
                /* The following line can be enabled for debugging purposes */
                //print_r('<br />Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE2DATA due to user error<br />');

                $list_type_session = grab_array_var($_SESSION[$wizard_name], 'list_type', '');
                $list_type = grab_array_var($inargs, 'list-type', $list_type_session);

                $container_names_session = grab_array_var($_SESSION[$wizard_name], 'container_names', array());
                $container_names = grab_array_var($inargs, 'containernames', $container_names_session);
                $container_names = array_values(array_filter($container_names));

                $network_names_session = grab_array_var($_SESSION[$wizard_name], 'network_names', array());
                $network_names = grab_array_var($inargs, 'network_names', $network_names_session);
                $network_names = array_values(array_filter($network_names));

                $check_types_session = grab_array_var($_SESSION[$wizard_name], 'check_types', array());
                $check_types = grab_array_var($inargs, 'check_types', $check_types_session);

                $hostname_session = grab_array_var($_SESSION[$wizard_name], 'hostname', '');
                $hostname = grab_array_var($inargs, 'hostname', $hostname_session);

                $address = grab_array_var($_SESSION[$wizard_name], 'ip_address', '');
            }

            // Old variables. These should not change for the rest of the wizard, so it shouldn't matter whether we're going forwards or backwards.
            $check_types = grab_array_var($_SESSION[$wizard_name], 'check_types', array());
            $list_type = grab_array_var($_SESSION[$wizard_name], 'list_type', "none");
            $container_names = grab_array_var($_SESSION[$wizard_name], 'container_names', array());
            $network_names = grab_array_var($_SESSION[$wizard_name], 'network_names', array());

            // New variable. This should also just kinda work.
            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());

            ########################################################################################
            # Load the html
            # - The html needs to end up in the $output string, so use ob_start() and ob_get_clean()
            #   to load the PHP from the Step2 file into the $output string.
            ########################################################################################
            ob_start();
            include __DIR__.'/steps/step2.php';
            $output = ob_get_clean();

            break;

        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE2HTML */
        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE4HTML */
            $back = array_key_exists("backButton", $_POST);

            /* If the user came back from CONFIGWIZARD_MODE_GETSTAGE3HTML then we don't need to revalidate and check for errors */
            if ($back) break;


            $hostname_session = grab_array_var($_SESSION, 'hostname', '');
            $hostname = grab_array_var($inargs, 'hostname', $hostname_session);

            $remote = grab_array_var($_SESSION, 'remote', '');

            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());
            $serviceargs = grab_array_var($inargs, 'serviceargs', $serviceargs);

            $containernames = grab_array_var($_SESSION[$wizard_name], 'containernames', array());
            $containernames = grab_array_var($inargs, 'containernames');

            if (!have_value($hostname)) {
                $errmsg[$errors++] = _("No host name specified.");

            } elseif (!is_valid_host_name($hostname)) {
                $errmsg[$errors++] = _("Invalid host name.");
            }

            $_SESSION[$wizard_name]['hostname'] = $hostname;

            if (empty($serviceargs)) {
                $errmsg[$errors++] = _("serviceargs is empty. This error should never be reached. Please contact the config wizard maintainer.");
            }

            $check_types = grab_array_var($_SESSION[$wizard_name], 'check_types', array());

            foreach ($check_types as $check_type => $on) {
                // All checks need service descriptions.
                if (!is_valid_service_name($serviceargs[$check_type]['description'])) {
                    $errmsg[$errors++] = _('The check for ') . $check_type . _(' has an invalid service description') . ' (' . encode_form_val($serviceargs[$check_type]['description']) . ')';
                }

                $serviceargs[$check_type]['timeout'] = intval($serviceargs[$check_type]['timeout']);

                if ($check_type === 'cpu' || $check_type === 'memory' && !$serviceargs[$check_type]['only']) {
                    // If we're not *only* using aggregate statistics, we need to check that thresholds were entered for each container.

                    foreach ($serviceargs[$check_type]['containers']['warning'] as $i => $value) {
                        if (empty($value)) {
                            $errmsg[$errors++] = sprintf(_('Container \'%1$s\' does not have a WARNING value for its %2$s check'), $containernames[$i], strtoupper($check_type));
                        }
                    }

                    foreach ($serviceargs[$check_type]['containers']['critical'] as $i => $value) {
                        if (empty($value)) {
                            $errmsg[$errors++] = sprintf(_('Container \'%1$s\' does not have a CRITICAL value for its %2$s check'), $containernames[$i], strtoupper($check_type));
                        }
                    }
                }
            }

            if ($errors>0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;

                if (!array_key_exists('serviceargs', $_SESSION[$wizard_name])) {
                    // If we've never assigned serviceargs to SESSION, it's fine to overwrite even if they're not valid.
                    $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
                    $_SESSION[$wizard_name]['containernames'] = $containernames;
                }
            } else {
                $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
                $_SESSION[$wizard_name]['containernames'] = $containernames;
            }

            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE2DATA */
            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:
            $back = array_key_exists('backButton', $_POST);


            $output = '
            ';

            /* The next line ends CONFIGWIZARD_MODE_GETSTAGE3HTML */
            break;


        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            $back = array_key_exists("backButton", $_POST);

            if ($back) {
                break;
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
            $output = '';
            break;


        case CONFIGWIZARD_MODE_GETOBJECTS:
            $remote = $_SESSION[$wizard_name]['remote'];
            $address = $_SESSION[$wizard_name]['ip_address'];
            $hostname = $_SESSION[$wizard_name]['hostname'];
            $socket = $_SESSION[$wizard_name]['socket'];
            $baseurl = $_SESSION[$wizard_name]['baseurl'];

            $token = escapeshellarg($_SESSION[$wizard_name]['token']);
            $port = $_SESSION[$wizard_name]['port'];

            $list_type = $_SESSION[$wizard_name]['list_type'];
            $container_names = $_SESSION[$wizard_name]['container_names'];
            $network_names = $_SESSION[$wizard_name]['network_names'];

            $check_types = $_SESSION[$wizard_name]['check_types'];
            $serviceargs = $_SESSION[$wizard_name]['serviceargs'];

            $cert = $_SESSION[$wizard_name]['cert'];
            $key = $_SESSION[$wizard_name]['key'];
            $cacert = $_SESSION[$wizard_name]['cacert'];

            // Escape values for check_command line
            if (function_exists('nagiosccm_replace_command_line')) {
                $token = nagiosccm_replace_command_line($token);
            } else {
                $token = str_replace('!', '\!', $token);
            }

            $objs = array();

            if (!host_exists($hostname)) {
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_linuxserver_host",
                    "host_name" => $hostname,
                    'icon_image' => 'docker.png',
                    "address" => $address,
                    "_xiwizard" => $wizard_name,
                );
            }

            foreach ($check_types as $check_type => $on) {
                $options_string = array();
                $sa = $serviceargs[$check_type];
                $options_string[] = "-H $baseurl";

                if (!empty($socket)) {
                    $options_string[] = '-s ' . $socket;
                }

                $options_string[] = "--check-type 'containers_" . $check_type . "'";

                if ($list_type === "containers") {
                    $to_monitor = "-C '" . implode(",", $container_names) . "'";

                } elseif ($list_type === "networks") {
                    $to_monitor = "-N '" . implode(",", $network_names) . "'";

                } else {
                    $list_type = 'all';
                    $to_monitor = "--all";
                }

                if ($remote === "api") {
                    if (!empty($cert))      $options_string[] = "--cert ". $cert;
                    if (!empty($key))       $options_string[] = "--key ". $key;
                    if (!empty($cacert))    $options_string[] = "--cacert ". $cacert;
                }

                $options_string[] = $to_monitor;
                $options_string[] = "-t " . $sa['timeout'];

                if (array_key_exists("networks-avg", $sa)) {
                    $options_string[] = "--networks-use-avg";
                }

                if ($check_type === "healthy") {
                    if ($sa["no-healthcheck"] === "ignored") {
                        $options_string[] = "--ignore-no-healthcheck";
                    } elseif ($sa["no-healthcheck"] === "healthy") {
                        $options_string[] = "--no-check-is-healthy";
                    }
                }

                if (in_array($check_type, array("running", "healthy"))) {
                    if (array_key_exists("percentage", $sa) && $sa["percentage"] === "on") {
                        $options_string[] = "--percentage";
                    }
                }

                if (in_array($check_type, array("running", "healthy"))) {
                    if (array_key_exists("bad", $sa) && $sa["bad"] === "on") {
                        $options_string[] = "-l";
                    }
                }

                if (in_array($check_type, array("exist", "running", "healthy"))) {
                    $options_string[] = "-w '" . $sa['warning'] . "'";
                    $options_string[] = "-c '" . $sa['critical'] . "'";

                } else {
                    $warning = array();
                    $critical = array();

                    if (array_key_exists("aggregate", $sa)) {
                        if (array_key_exists("total", $sa)) {
                            $options_string[] = "--total-usage ";
                            $warning[] = $sa['total-thresholds']['warning'];
                            $critical[] = $sa['total-thresholds']['critical'];
                        }
                        if (array_key_exists("avg", $sa)) {
                            $options_string[] = "--total-average ";
                            $warning[] = $sa['avg-thresholds']['warning'];
                            $critical[] = $sa['avg-thresholds']['critical'];
                        }
                        if (!array_key_exists("only", $sa)) {
                            $warning = array_merge($warning, $sa[$list_type]['warning']);
                            $critical = array_merge($critical, $sa[$list_type]['critical']);
                        }
                    } else {
                        $warning = $sa[$list_type]['warning'];
                        $critical = $sa[$list_type]['critical'];
                    }

                    if ($check_type === "memory") {
                        if (array_key_exists("percentage", $sa)) {
                            switch($sa["percentage"]) {
                                case 'kibibytes':
                                    $options_string[] = "--memory-unit KiB";
                                    break;
                                case 'mebibytes':
                                    $options_string[] = "--memory-unit MiB";
                                    break;
                                case 'gibibytes':
                                    $options_string[] = "--memory-unit GiB";
                                    break;
                                case 'percentage':
                                    $options_string[] = "--percentage";
                                    break;
                                case 'bytes':
                                default:
                                    break;
                            }
                        }
                    }

                    $warning = implode(",", $warning);
                    $critical = implode(",", $critical);
                    $options_string[] = "-w '" . $warning . "'";
                    $options_string[] = "-c '" . $critical . "'";
                }

                if ($remote === "api") {

                    $all_options = implode(" ", $options_string);
                    $full_check_command = "check_docker!" . $all_options;

                } else {

                    $all_options = "-t " . $token . " -P ". $port . " -M plugins/check_docker.py -q \"";

                    foreach ($options_string as $ind => $option) {
                        $options_string[$ind] = "args=". $option;
                    }

                    $options_string = implode(",", $options_string);
                    $all_options .= $options_string . "\"";
                    $full_check_command = 'check_xi_ncpa!' . $all_options;
                }

                $objs[] = array(
                    'type'                  => OBJECTTYPE_SERVICE,
                    'host_name'             => $hostname,
                    'service_description'   => $sa['description'],
                    'icon_image'            => 'docker.png',
                    'check_command'         => $full_check_command,
                    '_xiwizard'             => $wizard_name,
                );
            }

            /* Return the object definitions to the wizard */
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            /* clear the session variables for this wizard run */
            unset ($_SESSION[$wizard_name]);

            /* The next line ends CONFIGWIZARD_MODE_GETOBJECTS */
            break;

        default:
            break;
    };

    return $output;
}

function ncpa_plugin_check($url, &$cmd) {
    $url = escapeshellarg($url);
    $cmd = "curl " . $url . " -g -f -k --connect-timeout 10";

    $ret = 0;
    exec($cmd, $data, $ret);
    $data = implode("", $data);

    if ($ret) {
        return 1; // cURL-specific error
    }

    $data = json_decode($data, true);

    if (!$data) {
        return 2; // Not JSON data
    }

    if (!array_key_exists('plugins', $data)) {
        return 3; // Not the correct json data
    }

    $found_it = 4; // If not changed, plugin not installed.

    foreach($data['plugins'] as $plugin) {
        if ($plugin === "check_docker.py") {
            $found_it = 0; // Everything is good.
            break;
        }
    }

    return $found_it;
}
