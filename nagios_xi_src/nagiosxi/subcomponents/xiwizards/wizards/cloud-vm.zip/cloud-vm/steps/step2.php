    <!--                                   -->
    <!-- The initial data set from Step 1. -->
    <!--                                   -->
    <input type="hidden" id="hostname" name="hostname" value="<?= encode_form_val($hostname) ?>">
    <input type="hidden" id="operation" name="operation" value="<?= encode_form_val($operation) ?>">
    <input type="hidden" id="selectedhostconfig" name="selectedhostconfig" value="<?= encode_form_val($selectedhostconfig) ?>">
    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

    <input type="hidden" name="ip_address" value="<?= encode_form_val($address) ?>">
    <input type="hidden" name="port" value="<?= encode_form_val($port) ?>">
    <input type="hidden" name="token" value="<?= encode_form_val($token) ?>">
    <input type="hidden" name="no_ssl_verify" value="<?= intval($no_ssl_verify) ?>">

<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
    <div class="container m-0 g-0">

        <h2 class="mb-2"><?= _("Connection Information") ?></h2>

        <div class="row mb-2">
            <div class="col-sm-6">
                <label for="ip_address" class="form-label"><?= _("Address") ?> </label>
                <div class="input-group position-relative">
                    <input type="text" name="ip_address" id="ip_address" value="<?= encode_form_val($address) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter Address") ?>" disabled="on">
                    <i id="_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>

        <div class="row mb-2">
            <div class="col-sm-6">
                <label for="hostname" class="form-label"><?= _("Host Name") ?> <?= xi6_info_tooltip(_("The hostname you'd like to have associated with this NCPA Agent")) ?></label>
                <div class="input-group position-relative">
                    <input type="text" name="hostname" id="hostname" value="<?= encode_form_val($hostname) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter Host Name") ?>" >
                    <i id="hostname_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>

        <div class="row mb-2">
            <div class="col-sm-6">
                <label for="" class="form-label"><?= _("Port") ?> </label>
                <div class="input-group position-relative">
                    <input type="text" name="" id="" value="<?= encode_form_val($port) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter Port") ?>" disabled="on">
                    <i id="_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>
<?php
    // Set defaults for services
    $default_services['cpu_usage']['monitor'] = 'on';
    $default_services['cpu_usage']['warning'] = 20;
    $default_services['cpu_usage']['critical'] = 40;
    $default_services['cpu_usage']['average'] = 1;
    $default_services['memory_usage']['monitor'] = 'on';
    $default_services['memory_usage']['warning'] = 50;
    $default_services['memory_usage']['critical'] = 80;
    $default_services['swap_usage']['monitor'] = 'on';
    $default_services['swap_usage']['warning'] = 5;
    $default_services['swap_usage']['critical'] = 10;

    foreach ($root['disk']['logical'] as $title => $value) {
        if (empty($value['device_name'])) {
            continue;
        }

        $default_services['disk'][$title]['monitor'] = 'on';
        $default_services['disk'][$title]['warning'] = 70;
        $default_services['disk'][$title]['critical'] = 90;
        $default_services['disk'][$title]['name'] = $value['device_name'];

        if (is_array($value['device_name'])) {
            $default_services['disk'][$title]['name'] = $value['device_name'][0];
        }
    }

    ksort($root['interface']);

    foreach ($root['interface'] as $title => $value) {
        if (stripos($title, "Local Area Connection") !== false || stripos($title, "eth") !== false || stripos($title, "ens") !== false || stripos($title, "Wireless") !== false) {
            $default_services['interface'][$title]['monitor'] = 'on';
        } else {
            $default_services['interface'][$title]['monitor'] = 'off';
        }

        $default_services['interface'][$title]['warning'] = 10;
        $default_services['interface'][$title]['critical'] = 100;
        $default_services['interface'][$title]['name'] = $title;
    }

    // Create only one default process to monitor...we will add more via JS if someone wants to add more
    $default_services['process'][0]['monitor'] = 'off';
    $default_services['process'][0]['name'] = '';
    $default_services['process'][0]['display_name'] = '';
    $default_services['process'][0]['count']['warning'] = 60;
    $default_services['process'][0]['count']['critical'] = 100;

    // Create only one service too if there are no services saved
    $default_services['services'][0]['monitor'] = 'off';
    $default_services['services'][0]['name'] = '';
    $default_services['services'][0]['state'] = 'running';

    if (!isset($services)) {
        $services = $default_services;
    }

    # TODO: When is this triggered?
    if ($alternative_host_check) {
?>
        <input type="hidden" name="alternative_host_check" value="on"/>

        <h2 class="mt-4"><?= _('Host Check') ?></h2>
        <p><?= _('Ping failed to detect this host. Please specify a TCP Port which will always be open, so that we can use it to determine host state') ?></p>

        <div class="row mb-2">
            <div class="col-sm-6">
                <label for="tcp_check_port" class="form-label"><?= _('Host Check Port:') ?> </label>
                <div class="input-group position-relative">
                    <input type="text" name="tcp_check_port" id="tcp_check_port" value="<?= encode_form_val($tcp_check_port) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter Host Check Port:") ?>" >
                    <i id="tcp_check_port_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>
<?php
    }
?>
        <!--                         -->
        <!-- The metrics to monitor. -->
        <!--                         -->
        <h2 class="mt-4"><?= _("CPU Metrics") ?></h2>
        <p><?= _("Specify the metrics you'd like to monitor on the NCPA Agent") ?>.</p>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-3 mt-0 pt-1">
                        <input type="checkbox" id="cpum" class="form-check-input" name="services[cpu_usage][monitor]"  <?= is_checked(grab_array_var($services['cpu_usage'], "monitor"), "on") ?> >
                        <label for="cpum" class="form-check-label bold"><?= _('CPU Usage') ?> <?= xi6_info_tooltip(_('Check the CPU usage of the system')) ?></label>
                    </div>
                    <div class="col-sm-6 mt-0">
                        <div class="row g-0 p-0">
                            <div class="col-sm-6 mt-0 pe-1">
                        		<div class="input-group input-group-sm">
                            		<span class="input-group-text">
                                        <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400">warning</i>
                            		</span>
                            		<input type="text" id="services[cpu_usage][warning]" name="services[cpu_usage][warning]" value="<?= encode_form_val($services['cpu_usage']['warning']) ?>" class="form-control form-control-sm monitor">
		                            <span class="input-group-text">%</span>
                            		<i id="services_cpu_usage_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        		</div>
                            </div>
                			<div class="col-sm-6 mt-0">
		                        <div class="input-group input-group-sm">
		                            <span class="input-group-text">
                                        <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
		                            </span>
		                            <input type="text" id="services[cpu_usage][critical]" name="services[cpu_usage][critical]" value="<?= encode_form_val($services['cpu_usage']['critical']) ?>" class="form-control form-control-sm monitor">
		                            <span class="input-group-text">%</span>
		                            <i id="services_cpu_usage_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
		                        </div>
		                    </div>
		                </div>
                        <div class="row g-0 p-0">
                            <div class="col-sm-12 mt-2 pe-1">
                                <input type="checkbox" class="form-check-input" name="services[cpu_usage][average]" id="services[cpu_usage][average]" <?= is_checked($services['cpu_usage']['average'], 1) ?>>
                                <label for="services[cpu_usage][average]" class="form-check-label bold"><?= _('Show average CPU usage instead of per cpu core') ?></label>
                            </div>
		                </div>
                </fieldset>
            </div>
        </div>

        <h2 class="mt-2 mb-2"><?= _('Memory Metrics') ?></h2>

        <div class="row mb-2">
            <div class="col-sm-8">
                <fieldset class="row g-2 mt-0 mb-1 wz-fieldset">
                    <div class="form-check col-sm-9 mt-0 pt-0 ps-0">
                        <label for="default_mem_units" class="form-check-label bold select-cf-option"><?= _('Default units for memory metric ouput') ?></label>
                        <div class="input-group position-relative col-sm-8">
                            <select class="form-select form-select-sm form-control-sm monitor rounded" id="default_mem_units" name="default_mem_units">
                                <option value="b" <?= is_selected($default_mem_units, 'b') ?>>b</option>
                                <option value="B" <?= is_selected($default_mem_units, 'B') ?>>B</option>
                                <option value="k" <?= is_selected($default_mem_units, 'k') ?>>k</option>
                                <option value="Ki" <?= is_selected($default_mem_units, 'Ki') ?>>Ki</option>
                                <option value="G" <?= is_selected($default_mem_units, 'G') ?>>G</option>
                                <option value="Gi" <?= is_selected($default_mem_units, 'Gi') ?>>Gi</option>
                                <option value="T" <?= is_selected($default_mem_units, 'T') ?>>T</option>
                                <option value="Ti" <?= is_selected($default_mem_units, 'Ti') ?>>Ti</option>
                            </select>
                            <div class="invalid-feedback">
                                Please select the default units of measure.
                            </div>
                            <i id="default_mem_units_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-3 mt-0 pt-1">
                        <input type="checkbox" id="mainm" class="form-check-input" name="services[memory_usage][monitor]"  <?= is_checked(grab_array_var($services['memory_usage'], 'monitor'), 'on') ?> >
                        <label for="mainm" class="form-check-label bold"><?= _('Main Memory Usage') ?> <?= xi6_info_tooltip(_("Monitor the main memory of the system. This metric is the percentage of main memory used.")) ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400">warning</i>
                            </span>
                            <input type="text" id="services[memory_usage][warning]" name="services[memory_usage][warning]" value="<?= encode_form_val($services['memory_usage']['warning']) ?>" class="form-control form-control-sm monitor">
		                    <span class="input-group-text">%</span>
                            <i id="services_memory_usage_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>                            </span>
                            <input type="text" id="services[memory_usage][critical]" name="services[memory_usage][critical]" value="<?= encode_form_val($services['memory_usage']['critical']) ?>" class="form-control form-control-sm monitor">
		                    <span class="input-group-text">%</span>
                            <i id="services_memory_usage_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-3 mt-0 pt-1">
                        <input type="checkbox" id="swapm" class="form-check-input" name="services[swap_usage][monitor]"  <?= is_checked(grab_array_var($services['swap_usage'], 'monitor'), 'on') ?> >
                        <label for="swapm" class="form-check-label bold"><?= _('Swap Usage') ?> <?= xi6_info_tooltip(_("Monitor the percentage of allocated swap used by the system.")) ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400">warning</i>                            </span>
                            <input type="text" id="services[swap_usage][warning]" name="services[swap_usage][warning]" value="<?= encode_form_val($services['swap_usage']['warning']) ?>" class="form-control form-control-sm monitor">
		                    <span class="input-group-text">%</span>
                            <i id="services_swap_usage_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>                            </span>
                            <input type="text" id="services[swap_usage][critical]" name="services[swap_usage][critical]" value="<?= encode_form_val($services['swap_usage']['critical']) ?>" class="form-control form-control-sm monitor">
		                    <span class="input-group-text">%</span>
                            <i id="services_swap_usage_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>
        
        <h2 class="mt-4"><?= _("Disk Metrics") ?></h2>
        <p><?= _("Specify the disks the the warning and critical percentages for disk capacity") ?>.</p>
<?php
    $id = 0;

    foreach ($services['disk'] as $title => $metrics) {
        $id++;
?>
        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-3 mt-0 pt-0">
                        <div class="input-group input-group-sm">
                            <input type="checkbox" id="d<?= $id ?>" class="form-check-input mt-2 me-2" name="services[disk][<?= $title ?>][monitor]" <?= is_checked(grab_array_var($services['disk'][$title], 'monitor'), 'on') ?>>
                            <input type="text" class="form-control form-control-sm ps-1" name="services[disk][<?= $title ?>][name]" id="services[disk][<?= $title ?>][name]" value="<?= $metrics['name'] ?>" disabled>
                            <input type="hidden" name="services[disk][<?= $title ?>][name]" value="<?= $metrics['name'] ?>">
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400">warning</i>                            </span>
                            <input type="text" name="services[disk][<?= $title ?>][warning]" id="services[disk][<?= $title ?>][warning]" value="<?= encode_form_val($services['disk'][$title]['warning']) ?>" class="form-control form-control-sm monitor">
                            <span class="input-group-text">%</span>
                            <i id="services_disk_<?= $title ?>_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>                            </span>
                            <input type="text" name="services[disk][<?= $title ?>][critical]" id="services[disk][<?= $title ?>][critical]" value="<?= encode_form_val($services['disk'][$title]['critical']) ?>" class="form-control form-control-sm monitor">
                            <span class="input-group-text">%</span>
                            <i id="services_disk_<?= $title ?>_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>
<?php
    }
?>
        <h2 class="mt-4"><?= _('Network Interface Metrics') ?></h2>
        <p><?= _("Specify reasonable bandwidths for your network interfaces. Note that these measurements are in megabits") ?>.</p>
<?php
    $id = 0;
    $hidden = false;

    foreach ($services['interface'] as $title => $metrics) {
        $id++;
        $hide = '';

        if (!is_checked(grab_array_var($services['interface'][$title], 'monitor'), 'on')) {
            $hide = 'hidden-interface visually-hidden';
        }
?>
        <div class="row <?= $hide ?>">
            <div class="col-sm-8">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-3 mt-0 pt-0">
                        <div class="input-group input-group-sm">
                            <input type="checkbox" id="ni<?= $id ?>" class="form-check-input mt-2 me-2" name="services[interface][<?= $title ?>][monitor]" <?= is_checked(grab_array_var($services['interface'][$title], 'monitor'), 'on') ?>>
                            <input type="text" class="form-control form-control-sm ps-1" name="services[interface][<?= $title ?>][name]" value="<?= encode_form_val(str_replace("|", "/", $title)) ?>" disabled>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400">warning</i>                            </span>
                            <input type="text" name="services[interface][<?= $title ?>][warning]" id="services[interface][<?= $title ?>][warning]" value="<?= encode_form_val($services['interface'][$title]['warning']) ?>" class="form-control form-control-sm monitor">
                            <span class="input-group-text">Mb</span>
                            <i id="services_interface_<?= $title ?>" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>                            </span>
                            <input type="text" name="services[interface][<?= $title ?>][critical]" id="services[interface][<?= $title ?>][critical]" value="<?= encode_form_val($services['interface'][$title]['critical']) ?>" class="form-control form-control-sm monitor">
                            <span class="input-group-text">Mb</span>
                            <i id="services_interface_<?= $title ?>" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>
<?php
    }
?>
        <p><a class="btn btn-link show-hidden-interfaces"><?= _("Show all interfaces") ?></a></p>

        <h2 class="mt-4"><?= _("Services") ?></h2>
        <p><?= _("Specify which services should be running or stopped.") ?> <?= xi6_info_tooltip(_("Depending on the selected state, you will recieve an OK when the process is in the selected state and a CRITICAL if the process is not in the state selected.")) ?></p>

        <div class="row">
            <div class="col-sm-4 ms-3 ps-4">
                <label class="form-label bold"><?= _('Service Name') ?></label>
            </div>
            <div class="col-sm ms-2 ps-0">
                <label class="form-check-label bold"><?= _('Expected Status') ?></label>
            </div>
        </div>

        <div id="services-list">
<?php
    foreach ($services['services'] as $i => $metrics) {
?>
            <div class="row">
                <div class="col-sm-8">
                    <fieldset class="row g-2 mb-1 wz-fieldset">
                        <div class="form-check col-sm-6 mt-0 pt-0">
                            <div class="input-group input-group-sm">
                                <input type="checkbox" name="services[services][<?= $i ?>][monitor]" id="services[services][<?= $i ?>][monitor]" class="form-check-input mt-2 me-2" <?= is_checked($metrics['monitor'], 'on') ?>>
                                <input type="text" class="form-control form-control-sm ps-1" name="services[services][<?= $i ?>][name]" id="services[services][<?= $i ?>][name]" value="<?= encode_form_val($metrics['name']) ?>">
                                <div class="input-group-text">
                                    <span style="cursor: pointer;" class="service-selector" data-id="<?= $i ?>">
                                        <i class="material-symbols-outlined md-16 md-400 md-middle md-action tt-bind" title="<?= _("Select services from currently running services list") ?>">list_alt</i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="form-check col-sm-auto ms-4 mt-0 pt-1">
                            <input type="radio" value="running" name="services[services][<?= $i ?>][state]" id="services[services][<?= $i ?>][state]" class="form-check-input" <?= is_checked($metrics['state'], 'running') ?>>

                            <label class="form-check-label"><?= _("Running") ?></label>
                        </div>
                        <div class="form-check col-sm-auto ms-3 mt-0 pt-1">
                            <input type="radio" value="stopped" name="services[services][<?= $i ?>][state]" id="services[services][<?= $i ?>][state]" class="form-check-input" <?= is_checked($metrics['state'], 'stopped') ?>>
                            <label class="form-check-label"><?= _("Stopped") ?></label>
                        </div>
                    </fieldset>
                </div>
            </div>
<?php
    }
?>
        </div>  <!-- services-list -->
<?php

    // Create a list of services for the JS
    $service_list = '';

    ksort($root['services']);

    foreach ($root['services'] as $service => $status) {
        $service_list .= '<option value="'.encode_form_val($service).'" data-status="'.encode_form_val($status).'">'.encode_form_val($service).' ('.encode_form_val($status).')</option>';
    }
?>
        <p><a style="cursor: pointer;" id="add-new-service" class="btn btn-link"><i class="fa fa-plus"></i> <?= _('Add Another Service Check') ?></a></p>

        <h2 class="mt-4"><?= _('Running Processes') ?></h2>
        <p><?= _("Specify which processes should be running, and how many should be") ?>.</p>

        <div class="row">
            <div class="col-sm-8">
                <fieldset class="row g-2">
                    <div class="col-sm-3">
                        <label class="form-label bold mb-0 ms-3 ps-1"><?= _('Process Name') ?></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><?= _('Display Name') ?></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><?= _('Warning #') ?></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><?= _('Critical #') ?></label>
                    </div>
                </fieldset>
            </div>
        </div>

        <div id="process-list">
<?php
    foreach ($services['process'] as $i => $metrics) {
?>
            <div class="row">
                <div class="col-sm-8">
                    <fieldset class="row g-2 mb-1 wz-fieldset">
                        <div class="form-check col-sm-3 mt-0 pt-0">
                            <div class="input-group input-group-sm">
                                <input type="checkbox" class="form-check-input mt-2 me-2" name="services[process][<?= $i ?>][monitor]" id="services[process][<?= $i ?>][monitor]" <?= is_checked($metrics['monitor'], 'on') ?>>
                                <input type="text" class="form-control form-control-sm ps-1" name="services[process][<?= $i ?>][name]" id="services[process][<?= $i ?>][name]" value="<?= encode_form_val($metrics['name']) ?>">
                                <i id="services_process_<?= $i ?>_monitor_Alert-cust-sm" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                        <div class="col-sm-3 mt-0">
                            <div class="input-group input-group-sm">
                                <input type="text" class="form-control form-control-sm monitor" name="services[process][<?= $i ?>][display_name]" id="services[process][<?= $i ?>][display_name]" value="<?= encode_form_val($metrics['display_name']) ?>">
                                <i id="services_process_<?= $i ?>_display_name_Alert-cust-sm" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                        <div class="col-sm-3 mt-0">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text">
                                    <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400">warning</i>                                </span>
                                <input type="text" class="form-control form-control-sm monitor" name="services[process][<?= $i ?>][count][warning]" id="services[process][<?= $i ?>][count][warning]" value="<?= encode_form_val($metrics['count']['warning']) ?>">
                                <i id="services_process_<?= $i ?>_count_warning_Alert-cust-sm" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                        <div class="col-sm-3 mt-0">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text">
                                    <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>                                </span>
                                <input type="text" class="form-control form-control-sm monitor" size="2" name="services[process][<?= $i ?>][count][critical]" value="<?= encode_form_val($metrics['count']['critical']) ?>">
                                <i id="services_process_<?= $i ?>_count_critical_Alert-cust-sm" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                    </fieldset>
                </div>
            </div>
<?php
    }
?>
        </div>  <!-- process-list -->

        <p><a style="cursor: pointer;" id="add-new-process" class="btn btn-link"><i class="fa fa-plus"></i> <?= _('Add Another Process Check') ?></a></p>

    </div> <!-- container -->

    <script type="text/javascript">
        var processnum = <?= (count($services['process']) - 1) ?>;
        var servicenum = <?= (count($services['services']) - 1) ?>;

        var IF_SHOW = 0;

        $(document).ready(function() {
            $(".show-hidden-interfaces").click(function() {
                if (!IF_SHOW) {
                    IF_SHOW = 1;
                    $(this).html("<?= _('Hide unselected interfaces') ?>");
                    $(".hidden-interface").removeClass("visually-hidden");
                } else {
                    IF_SHOW = 0;
                    $(this).html("<?= _('Show all interfaces') ?>");

                    $(".hidden-interface").each(function() {
                        if (!$(this).find("input.checkbox").is(":checked")) {
                            $(this).addClass("visually-hidden");
                        }
                    });
                }
            });

            $("#add-new-process").click(function() {
                processnum++;

                row = "".concat(
'            <div class="row">',
'                <div class="col-sm-8">',
'                    <fieldset class="row g-2 mb-1 wz-fieldset">',
'                        <div class="form-check col-sm-3 mt-0 pt-0">',
'                            <div class="input-group input-group-sm">',
'                                <input type="checkbox" class="form-check-input mt-2 me-2" name="services[process]['+processnum+'][monitor]" id="services[process]['+processnum+'][monitor]">',
'                                <input type="text" class="form-control form-control-sm ps-1" name="services[process]['+processnum+'][name]" id="services[process]['+processnum+'][name]" value="">',
'                            </div>',
'                        </div>',
'                        <div class="col-sm-3 mt-0">',
'                            <div class="input-group input-group-sm">',
'                                <input type="text" class="form-control form-control-sm monitor" name="services[process]['+processnum+'][display_name]" id="services[process]['+processnum+'][display_name]" value="">',
'                            </div>',
'                        </div>',
'                        <div class="col-sm-3 mt-0">',
'                            <div class="input-group input-group-sm">',
'                                <span class="input-group-text">',
'                                    <i title="<?= _('Warning Threshold') ?>" class="material-symbols-outlined md-warning md-18 md-400 tt-bind">warning</i>',
'                                </span>',
'                                <input type="text" class="form-control form-control-sm monitor" name="services[process]['+processnum+'][count][warning]" id="services[process]['+processnum+'][count][warning]" value="<?= encode_form_val($metrics['count']['warning']) ?>">',
'                            </div>',
'                        </div>',
'                        <div class="col-sm-3 mt-0">',
'                            <div class="input-group input-group-sm">',
'                                <span class="input-group-text">',
'                                    <i title="<?= _('Critical Threshold') ?>" class="material-symbols-outlined md-critical md-18 md-400 tt-bind">error</i>',
'                                </span>',
'                                <input type="text" class="form-control form-control-sm monitor" size="2" name="services[process]['+processnum+'][count][critical]" value="<?= encode_form_val($metrics['count']['critical']) ?>">',
'                            </div>',
'                        </div>',
'                    </fieldset>',
'                </div>',
'            </div>');

                $("#process-list").append(row);
            });

            $("#add-new-service").click(function() {
                servicenum++;

                row = "".concat(
'            <div class="row">',
'                <div class="col-sm-8">',
'                    <fieldset class="row g-2 mb-1 wz-fieldset">',
'                        <div class="form-check col-sm-6 mt-0 pt-0">',
'                            <div class="input-group input-group-sm">',
'                                <input type="checkbox" name="services[services]['+servicenum+'][monitor]" id="services[services]['+servicenum+'][monitor]" class="form-check-input mt-2 me-2">',
'                                <input type="text" class="form-control form-control-sm ps-1" name="services[services]['+servicenum+'][name]" id="services[services]['+servicenum+'][name]" value="">',
'                                <div class="input-group-text">',
'                                    <span style="cursor: pointer;" class="service-selector" data-id="'+servicenum+'">',
'                                        <i class="material-symbols-outlined md-16 md-400 md-middle md-action tt-bind" title="<?= _("Select services from currently running services list") ?>">list_alt</i>',
'                                    </span>',
'                                </div>',
'                            </div>',
'                        </div>',
'                        <div class="form-check col-sm-auto ms-4 mt-0 pt-1">',
'                            <input name="services[services]['+servicenum+'][state]" type="radio" value="running" class="form-check-input" checked>',
'                            <label class="form-check-label"><?= _("Running") ?></label>',
'                        </div>',
'                        <div class="form-check col-sm-auto ms-3 mt-0 pt-1">',
'                            <input type="radio" value="stopped" name="services[services]['+servicenum+'][state]" id="services[services]['+servicenum+'][state]" class="form-check-input">',
'                            <label class="form-check-label"><?= _("Stopped") ?></label>',
'                        </div>',
'                    </fieldset>',
'                </div>',
'            </div>');

                $("#services-list").append(row);
            });

            $("#services-list").on("click", ".service-selector", function() {
                var service_id = $(this).data("id");
                var content = "".concat(
'<div>',
'    <h2><?= _("Services listed by the NCPA Agent") ?></h2>',
'    <p><?= _("Select a service that is either running or stopped from the NCPA client host to atuomatically fill in the service name and the expected state.") ?></p>',
'    <div>',
'        <select id="selected-service" class="form-select form-select-sm form-control-sm monitor rounded">',
'            <?= $service_list ?>',
'        </select>',
'    </div>',
'    <div style="margin-top: 6px;">',
'        <button data-serviceid="'+service_id+'" class="btn btn-sm btn-primary" id="add-selected-service">',
'            <?= _("Select this Service") ?>',
'        </button>',
'    </div>',
'</div>');

                $("#child_popup_container").width(450);
                $("#child_popup_layer").width(480);
                $("#child_popup_layer").css("position", "fixed");
                set_child_popup_content(content);
                display_child_popup();
            });

            $("#child_popup_container").on("click", "#add-selected-service", function() {
                var service_id = $(this).data("serviceid");
                var selected_service = $("#selected-service option:selected").val();
                var selected_state = $("#selected-service option:selected").data("status");

                $('input[name="services[services]['+service_id+'][name]"]').val(selected_service);
                $('input[name="services[services]['+service_id+'][monitor]"]').prop("checked", true);
                $('input[name="services[services]['+service_id+'][state]"][value="'+selected_state+'"]').prop("checked", true);
                close_child_popup();
            });
        });
    </script>

    <script src="../includes/configwizards/cloud-vm/cloud-vm.inc.js"></script>

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
