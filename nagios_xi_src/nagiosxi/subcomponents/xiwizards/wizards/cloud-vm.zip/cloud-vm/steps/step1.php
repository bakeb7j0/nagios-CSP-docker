    <input type="hidden" id="selectedhostconfig" name="selectedhostconfig" value="<?= encode_form_val($selectedhostconfig) ?>" />
    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
    <div class="container m-0 g-0">
        <!--                         -->
        <!-- The configuration form. -->
        <!--                         -->
        <div id="configForm">
            <div class="col-sm-6 border-block mb-4">
                <h2 class="mb-3"><?= _('Agent Installation') ?></h2>
                <div class="row">
                    <div class="col-sm-4 text-nowrap text-end">
                        <label><?= _('Agent Download') ?>:</label>
                    </div>
                    <div class="col-sm">
                        <a href="https://www.nagios.org/ncpa/#downloads" target="_blank"><i class="material-symbols-outlined md-action md-20 md-400 md-middle">download</i> <b><?= _('Download NCPA') ?></b></a>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-sm-4 text-nowrap text-end">
                        <label><?= _('Installation Guide') ?>:</label></td>
                    </div>
                    <div class="col-sm">
                        <a href="https://assets.nagios.com/downloads/ncpa/docs/Installing_NCPA.pdf" target="_blank"><i class="material-symbols-outlined md-action md-20 md-400 md-middle">description</i> <b><?= _('Installing NCPA') ?></b></a>
                    </div>
                </div>
                <p><?= _("Note: FreeBSD, Container Distributions, and One-click apps are not yet supported in this configuration wizard.") ?></p>
            </div>

            <h2 class="ul"><?= _('Connect to NCPA') ?></h2>

            <div class="row mb-3 mt-4">
                <div class="col-sm">
                    <input type="checkbox" id="no_ssl_verify" name="no_ssl_verify" class="form-check-input mt-1 me-2"  value="1" <?= is_checked($no_ssl_verify, 1) ?>>
                    <label for="no_ssl_verify" class="form-check-label bold">
                        <?= _("Do not verify SSL certificate") ?>
                    </label>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="ip_address" class="form-label form-item-required"><?= _('Address') ?> <?= xi6_info_tooltip(_('The IP address or FQDNS name used to connect to NCPA')) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="ip_address" id="ip_address" value="<?= encode_form_val($address) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Address") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the Address
                        </div>
                        <i id="ip_address_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="port" class="form-label form-item-required"><?= _('Port') ?> <?= xi6_info_tooltip(_('Port used to connect to NCPA.Defaults to port 5693')) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="port" id="port" value="<?= encode_form_val($port) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Port") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the Port number
                        </div>
                        <i id="port_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div id="changePasswordOption" class="row mb-3 mt-4 visually-hidden">
                <div class="col-sm">
                    <input type="checkbox" id="changePassword" class="form-check-input" name="changePassword">
                    <label for="changePassword" class="form-check-label bold"><?= _("Change Token") ?> <?= xi6_info_tooltip(_("Use to change the Token, otherwise, the existing Token will be preserved.")) ?></label>
                </div>
            </div>

            <div id="setPassword" class="row mb-2">
                <div class="col-sm-6">
                    <label for="token" class="form-label form-item-required"><?= _('Token') ?> <?= xi6_info_tooltip(_('Authentication token used to connect to NCPA')) ?></label>
                    <div class="input-group">
                        <input type="password" name="token" id="token" value="<?= encode_form_val($token) ?>" class="usermacro-detection form-control rounded-start usermacro-detection" autocomplete="off" placeholder="<?= _("Enter Token") ?>"  required>
                        <button type="button" class="btn btn-outline-secondary btn-show-secret rounded-end tt-bind" id="password-secret" title="<?= _("Show") ?>">
                            <span class="material-symbols-outlined md-22 md-pointer">Visibility</span>
                            <i id="token_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </button>
                        <div class="invalid-feedback">
                            Please enter the Token.
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- config -->
    </div> <!-- container -->

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
