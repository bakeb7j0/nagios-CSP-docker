#!/bin/bash

# Run this when you pull in the new plugin to make it work with the Nagios::Monitoring::Plugin package

BASEDIR=$(dirname $(readlink -f $0))

cd $BASEDIR
sed -i 's/plugin_exit/nagios_exit/' plugins/check_vmware_api.pl
sed -i 's/Monitoring::Plugin/Nagios::Monitoring::Plugin/' plugins/check_vmware_api
