import java.io.OutputStream;
import java.io.IOException;

/**Writes to nowhere*/
public class NullStream extends OutputStream {
  @Override
  public void write(int b) throws IOException {
  }
}