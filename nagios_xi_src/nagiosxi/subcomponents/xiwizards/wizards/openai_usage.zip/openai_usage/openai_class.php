<?php

/************************************************************************
 *
 * openai_class.php - A utility class set to check various OpenAI usage metrics
 *
 * OpenAI and Request handling classes
 *
 * Copyright (c) 2023 Nagios Enterprises, LLC (Phred White pwhit@nagios.com>)
 *
************************************************************************/

/************************************************************************
 * OpenAI Class
 ************************************************************************/
class openAI {
	public $base_url   = "https://api.openai.com";
	public $api_token  = "";
	public $org_id     = "";
	public $sess_token = "";
	public $uglify     = true;
	public $api_v      = 'v1';
	public $debug      = false;
	public $throttle   = 15; // Seconds to wait before next rqst (max of 5/min)
	public $error       = '';
	public $endpts;

	public function __construct($base_url = '', $api_token = '', $org_id = '', $sess_token = '', $uglify = true, $api_v = '', $debug = '') {
		// Override defaults
		$this->base_url = ($base_url) ? $base_url : $this->base_url;
		$this->api_token = ($api_token) ? $api_token : $this->api_token;
		$this->org_id = ($org_id) ? $org_id : $this->org_id;
		$this->sess_token = ($sess_token) ? $sess_token : $this->sess_token;
		$this->uglify = ($uglify) ? $uglify : $this->uglify;
		$this->api_v = ($api_v) ? $api_v : $this->api_v;
		$this->debug = ($debug) ? $debug : $this->debug;

		$this->setEndPoints();
	}

	/************************************************************************
	 * Value methods
	 ************************************************************************/

	/**
	 * Returns the total cost in cents ($0.01) for a given tim eperiod not to exceed 100 days.
	 *
	 * @param string $period - number of units _ time unit, e.g. 30_day, 11_week, 2_month.
	 *
	 * @return float - cost in cents.
	 */
	public function getTotalCost($period) {

		// Get dates based on period
		list($startDate, $endDate) = $this->periodToDates($period);
		$days = $this->datesToDays($startDate, $endDate);

		if ($days > 100) {
			nagios_exit("Error: Period exceeds maximum of 100 hundred days ($days days).", STATUS_UNKNOWN);
		}

		// Make the OpenAI request
		$response = $this->getCostForPeriod($startDate, $endDate);
		if (! $response) {
			nagios_exit($this->error, STATUS_UNKNOWN);
		}
		$response = json_decode($response, true);

		return $response['total_usage'];
	}

	/**
	 * Returns the total tokens and requests for a date, default is today, not to exceed 100 days n the past.
	 *
	 * @param string/null $date - in YYYY-MM-DD format.
	 *
	 * @return array - Total usage for 'n_requests', 'n_context_tokens_total', 'n_generated', 'n_generated_tokens_total'.
	 */
	public function getDailyTokens($date = '') {
		$dateTime = new DateTime();
		$today = $dateTime->format("Y-m-d");
		$date = ($date) ? $date : $today;
		$cols = ['n_requests', 'n_context_tokens_total', 'n_generated', 'n_generated_tokens_total'];

		// Make the OpenAI request
		$response = $this->getUsageForDate($date);
		if (! $response) {
			nagios_exit($this->error, STATUS_UNKNOWN);
		}
		$response = json_decode($response, true);

		foreach ($cols as $col) {
			$sums[$col] = 0;
		}

		if ($response['data']) {
			$sums = $this->sumColumns($response['data'], $cols);
		}
		return $sums;
	}


	/************************************************************************
	 * End point request methods
	 ************************************************************************/

	public function getUsageForDate($date) {
		return $this->doGet($this->endpts->UsageForDate . "?date=$date");
	}

	public function getUsers() {
		return $this->doGet($this->endpts->Users);
	}

	public function getCostForPeriod($startdate, $enddate) {
		return $this->doGet($this->endpts->CostForPeriod . "?start_date=$startdate&end_date=$enddate");
	}

	public function getSubscription() {
		return $this->doGet($this->endpts->Subscription);
	}

	public function getCreditGrants() {
		return $this->doGet($this->endpts->CreditGrants);
	}

	public function getRateLimits() {
		return $this->doGet($this->endpts->RateLimits);
	}

	public function getFeatures() {
		return $this->doGet($this->endpts->Features);
	}

	public function getBilling() {
		return $this->doGet($this->endpts->Billing);
	}

	// This also can be used to check API token
	public function testChat($chat_data = '') {
		if (!$chat_data) {
			$chat_data = '{
				 "model": "gpt-3.5-turbo",
				 "messages": [{"role": "user", "content": "Say this is a test!"}],
				 "temperature": 0.7
			}';
		}
		return $this->doPost($this->endpts->Chat, $chat_data);
	}

	/************************************************************************
	 * Raw Request methods
	 ************************************************************************/

	public function doGet($endpoint) {
		$rq = new apiRequest($this->base_url, $this->org_id, $this->debug);
		$token =  $this->getToken($endpoint);
		$response = $rq->doRequest($token, 'GET', $endpoint, false, $this->uglify);

		if (!$rq->error) {
			return $response;
		} else {
			$this->error = $this->formatError($rq);
			return false;
		}
	}

	public function doPost($endpoint, $data, $use_org_id = false) {
		$rq = new apiRequest("{$this->base_url}/$endpoint", $this->org_id, $this->debug);
		$token =  $this->getToken($endpoint);
		$response = $rq->doRequest($token, 'POST', $data, $use_org_id, $this->uglify);

		if (!$rq->error) {
			return $response;
		} else {
			$this->error = $this->formatError($rq);
			return false;
		}
	}

	/************************************************************************
	 * Utility methods
	 ************************************************************************/

	public function setEndPoints() {
		// Define endpoints - having endppoints as properties really helps with testing
		// Call this whenever org_id is set
		$this->endpts = (object) [
			"UsageForDate"  => "{$this->api_v}/usage",
			"Users"         => "{$this->api_v}/organizations/{$this->org_id}/users",
			"CostForPeriod" => "dashboard/billing/usage",
			"Subscription"  => "dashboard/billing/subscription",
			"Billing"       => "account/billing/overview",
			"CreditGrants"  => "dashboard/billing/credit_grants",
			"RateLimits"    => "dashboard/rate_limits",
			"Features"      => "dashboard/organizations/{$this->org_id}/features",
			"Chat"          => "{$this->api_v}/chat/completions",
		];
	}

	/**
	 * Returns the token required for categories of endpoints..
	 *
	 * @param string $endpoint - URL for endpoint.
	 * @return string - token to be used for this endpoint.
	 */
	public function getToken($endpoint) {
		$token = strpos($endpoint, 'v1/') !== false ? $this->api_token : $this->sess_token;
		return $token;
	}

	/**
	 * Converts period string (e.g. '12_week') into dates
	 *
	 * @param string   $period -  (4_week, 30_day).
	 * @return array           - e.g., [$startDate, $endDate].
	 */
	public function periodToDates($period) {
		// Get dates based on period (4_week, 30_day)
		list($cnt, $unit) = $this->parsePeriod($period);

		$dateTime = new DateTime();
		$endDate = $dateTime->format("Y-m-d");
		$dateTime->modify("-$cnt $unit");
		$startDate = $dateTime->format("Y-m-d");
		return [$startDate, $endDate];
	}

	/**
	 * Converts returns number of days betwen dates of format  2023-10-31
	 *
	 * @param string   $startDate
	 * @param string   $endDate
	 * @return integer           - number of days.
	 */
	public function datesToDays($startDate, $endDate) {
		$days = date_diff(new DateTime($endDate), new DateTime($startDate))->days;
		return $days;
	}

	/**
	 * Converts period string (e.g. '12_week') into separate values
	 * and returns them in an array. E.g. 12_week --> [12, week]
	 *
	 * @param string   $period -  (4_week, 30_day).
	 * @return array           - e.g., [$cnt, $unit].
	 */

	public function parsePeriod($period) {
		// Get dates based on period (4_week, 30_day)
		if (strpos($period, '_')) {
			list($cnt, $unit) = explode('_', rtrim($period, 's'));
		} else {
			list($cnt, $unit) = [1, rtrim($period, 's')];
		}
		return [$cnt, $unit];
	}

	/**
	 * Calls the provided function with the date for every day for the
	 * interval provided, excluding end date.
	 *
	 * @param string $startdate - first day of period in yyyy-mm-dd format
	 * @param string $enddate   - day after last day of period in yyyy-mm-dd format
	 * @param string $fncn      - name of method to be called with date in yyyy-mm-dd format
	 *                            as only parameter.
	 *
	 * @return array - array of results with index = date for result.
	 */
	public function IterateOnDate($startdate, $enddate, $fncn) {
		$start = new DateTime($startdate);
		$end = new DateTime($enddate);
		$delta = $end->diff($start)->format("%a");

		$interval = DateInterval::createFromDateString('1 day');
		$period = new DatePeriod($start, $interval, $end);

		$results = [];
		foreach ($period as $dt) {
			$date = $dt->format("Y-m-d");
			echo "Requesting $fncn($date)...\n";
			$results[$date] = $this->$fncn($date);
			if ($delta > 4 && $date < $enddate) {
				sleep($this->throttle);
			}
		}
		return $results;
	}

	// Converts simple 2-d array into a table with rows of tab-delimited values and a header row consisting of the keys.
	// $table is passed by reference so that multiple arrays of the same type can be aggregated.
	public function array_to_table($a, &$table) {
		If (!$table) {
			$table = implode("\t", array_keys($a[0])) ."\n";
		}
		foreach($a as $row) {
			$row[array_keys($row)[1]] = date("Y-m-d h:i:s", $row[array_keys($row)[1]]);
			$table .= implode("\t", $row) ."\n";
		}
	}

	public function sumColumns($a, $cols) {
		$result = [];
		foreach ($cols as $col) {
			$result[$col] = array_sum(array_column($a,$col));
		}
		return $result;
	}

	// Format an error for display
	public function formatError($rq_obj, $debug = false) {
		$response = "\nError: {$rq_obj->error}\n";

		if ($debug) {
			$response .= "Url: {$rq_obj->url}\n";
			$response .= "Header: " . print_r($rq_obj->header, true) . "\n";
		}
		return $response;
	}
}

/************************************************************************
 * Request Class
 ************************************************************************/
class apiRequest {
	public $header = [];
	public $url;
	public $curl_obj;
	public $curl_timeout = 60; //Seconds
	public $curl_connect_timeout = 10; //Seconds
	public $org_id;
	public $error = '';
	public $response ='';
	public $response_info ='';
	public $debug;

	public function __construct($base_url, $org_id = '', $debug = false) {
		$this->url = $base_url;
		$this->org_id = $org_id;
		$this->debug = $debug;
	}

	// $data is either a uri param string or a json post
	public function doRequest($token, $verb = 'GET', $data='', $use_org_id = false, $uglify = false) {
		$this->makeHeader($token, $use_org_id);
		$this->error = '';

		switch ( $verb ) {
			case 'GET':
				$this->curl_obj = curl_init($this->url .= "/$data");
				break;

			case'POST':
				$this->curl_obj = curl_init($this->url);
				curl_setopt($this->curl_obj, CURLOPT_POST, true);
				curl_setopt($this->curl_obj, CURLOPT_POSTFIELDS, $data);
				break;

			default:
				echo "Warning: Unimplemented verb $verb. We only know how to do GET and POST";
		}

		curl_setopt($this->curl_obj, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($this->curl_obj, CURLOPT_CONNECTTIMEOUT, $this->curl_connect_timeout);
		curl_setopt($this->curl_obj, CURLOPT_TIMEOUT, $this->curl_timeout);
		curl_setopt($this->curl_obj, CURLOPT_HTTPHEADER, $this->header);

		$this->response = curl_exec($this->curl_obj);

		// If the curl call itself failed, capture error and return false
		if (! $this->response) {
			$this->error = curl_error($this->curl_obj);
			if ($this->debug) {
				echo "\nthis->error: ".print_r($this->error,true)."\n";
			}
			curl_close($this->curl_obj);
			return false;
		}

		$this->response_info = curl_getinfo($this->curl_obj);
		curl_close($this->curl_obj);

		if ($this->debug) {
			echo "\nthis->response: ".print_r($this->response,true)."\n";
			echo "\nthis->response_info: ".print_r($this->response_info,true)."\n";
		}

		// Check if reponse has HTTP error, or API error.
		if ($this->has_error()) {
			return false;
		}

		if ($uglify) {
			return $this->uglify($this->response) . PHP_EOL;
		}

		return $this->response . PHP_EOL;
	}

	/************************************************************************
	 * Request Utility methods
	 ************************************************************************/

	protected function makeHeader($token, $use_org_id = false) {
		$this->header = [
			"Content-Type: application/json",
			"Authorization: Bearer $token",
			"User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15",
			"Accept: */*",
			"Connection: keep-alive",
			"Cache-Control: no-cache",
		];

		if ($use_org_id) {
			$this->header[] = "OpenAI-Organization: $this->org_id";
		}

		if ($this->debug) {
			echo "\nthis->header: ".print_r($this->header,true)."\n";
		}
	}

	public function uglify($json) {
		return json_encode(json_decode($json));
	}

	/**
	 * Checks response for error conditions. If an error is found, $this->error is set with message, and true is returned.
	 * If an error is found, $this->error is set with message, and true is returned.
	 *
	 * @return bool - false if no error is found, otherwise true.
	 */
	public function has_error() {

		// Check for HTTP errors
		if($this->response_info['http_code'] == '0') {
			$this->error = "The server at {$this->url} is not responding.";
			return true;
		}

		if (! $this->response) {
			$this->error = "The server at {$this->url} returned an empty response (HTTP Status: $this->response_info['http_code']).";
			return true;

		}

		// Check for Endpoint errors
		$response_array = json_decode($this->response, true);
		if (isset($response_array['error'])) {
			$this->error = "{$response_array['error']['message']} Error type: {$response_array['error']['type']}  (HTTP Status: {$this->response_info['http_code']})";
			return true;
		}

		if($this->response_info['http_code'] != '200') {
			$this->error = "The server at {$this->url} returned HTTP Status: {$this->response_info['http_code']}, but no error information was included.";
			return true;
		}

		return false;
	}
}
