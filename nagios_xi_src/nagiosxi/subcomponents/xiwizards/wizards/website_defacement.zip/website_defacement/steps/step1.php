<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
    <div class="container m-0 g-0">
        <!--                         -->
        <!-- The configuration form. -->
        <!--                         -->
        <div id="configForm">
            <h2 class="mb-2"><?= _("Website Information") ?></h2>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="" class="form-label form-item-required"><?= _('URL to Monitor') ?> <?= xi6_info_tooltip(_('The URL of the website you would like to monitor')) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="url" id="url" value="<?= encode_form_val($url) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter URL to Monitor") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the URL to Monitor
                        </div>
                        <i id="url_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

        </div> <!-- config -->
    </div> <!-- container -->

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
