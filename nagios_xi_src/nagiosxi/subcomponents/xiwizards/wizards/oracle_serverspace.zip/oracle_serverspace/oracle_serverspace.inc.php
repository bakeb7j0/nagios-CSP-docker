<?php
//
// Oracle Serverspace Config Wizard
// Copyright (c) 2010-2024 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');

oracleserverspace_configwizard_init();

function oracleserverspace_configwizard_init()
{
    $name = "oracleserverspace";
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "2.0.1",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _("Monitor an Oracle Server"),
        CONFIGWIZARD_DISPLAYTITLE => _("Oracle Serverspace"),
        CONFIGWIZARD_FUNCTION => "oracleserverspace_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "oracleserverspace.png",
        CONFIGWIZARD_FILTER_GROUPS => array('database', 'server'),
        CONFIGWIZARD_REQUIRES_VERSION => 60100
    );
    register_configwizard($name, $args);
}

/**
 * @param string $mode
 * @param null   $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function oracleserverspace_configwizard_func($mode = "", $inargs = null, &$outargs = null, &$result = null)
{
    $wizard_name = "oracleserverspace";

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:

            $address = grab_array_var($inargs, "ip_address", "");
            $port = grab_array_var($inargs, "port", "1521");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $sid = grab_array_var($inargs, "sid", "");

            # These will only be set by going back from step 2.
            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");

            //sanity check for wizard requirements
            $sanity = '';

            if (!file_exists('/usr/lib/oracle') && !file_exists('/usr/lib64/oracle')) {
                ob_start();
?>
            <div class="alert alert-danger w-50 mt-2">
                <div class="align-items-center d-flex pb-3">
                    <i class="material-symbols-outlined md-400">warning</i>
                    <span class="fw-bold pe-2"><?= _('Warning') ?>:</span> <?=_("Oracle libraries do not appear to be installed.") ?>
                </div>
                <div class="card card-p">
                    <p class="text-start"><?= _('See the') ?> <a href='https://assets.nagios.com/downloads/nagiosxi/docs/Oracle_Plugin_Installation.pdf' title='Install Instructions' target='_blank'><?= _("Oracle Plugin Installation") ?></a> <?= _("instructions for monitoring Oracle.") ?></p>
                </div>
            </div>
<?php
                $sanity = ob_get_clean();
            }

            # Get the existing host/node configurations.
            # TODO: Include passwords/secrets?
            $nodes = get_configwizard_hosts($wizard_name);

            ########################################################################################
            # Load the html
            # - The html needs to end up in the $output string, so use ob_start() and ob_get_clean()
            #   to load the PHP from the Step1 file into the $output string.
            ########################################################################################
            ob_start();
            include __DIR__.'/steps/step1.php';
            $output = ob_get_clean();

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address", "");
            $port = grab_array_var($inargs, "port", "");
            $username = grab_array_var($inargs, "username", "");
            $sid = grab_array_var($inargs, "sid", "");
            $password = grab_array_var($inargs, "password", "");

            $address = nagiosccm_replace_user_macros($address);
            $port = nagiosccm_replace_user_macros($port);
            $username = nagiosccm_replace_user_macros($username);
            $password = nagiosccm_replace_user_macros($password);

            // Check for errors
            $errors = 0;
            $errmsg = array();

            if (have_value($address) == false)
                $errmsg[$errors++] = _("No address specified.");
            if (have_value($port) == false)
                $errmsg[$errors++] = _("No port number specified.");
            if (have_value($username) == false)
                $errmsg[$errors++] = _("No username specified.");
            if (have_value($password) == false)
                $errmsg[$errors++] = _("No password specified.");

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $port = grab_array_var($inargs, "port", "");
            $sid = grab_array_var($inargs, "sid", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");

            $ha = @gethostbyaddr($address);

            if ($ha == "") {
                $ha = $address;
            }

            $hostname = grab_array_var($inargs, "hostname", $ha);

            $services = grab_array_var($inargs, "services", array(
                "connection-time" => "on",
                "connected-users" => "on",
                "sga-data-buffer-hit-ratio" => "on",
                "sga-library-cache-hit-ratio" => "on",
                "sga-dictionary-cache-hit-ratio" => "on",
                "sga-latches-hit-ratio" => "on",
                "sga-shared-pool-reload-ratio" => "on",
                "sga-shared-pool-free" => "on",
                "pga-in-memory-sort-ratio" => "on",
                "soft-parse-ratio" => "on",
                "retry-ratio" => "on",
                "redo-io-traffic" => "on",
                "roll-header-contention" => "on",
                "roll-block-contention" => "on",
                "roll-hit-ratio" => "on",
                "roll-wraps" => "on",
                "roll-extends" => "on",
                "flash-recovery-area-usage" => "on",
            ));

            $serviceargs = grab_array_var($inargs, "serviceargs", array(
                "connection-time_warning" => "1",
                "connection-time_critical" => "5",
                "connected-users_warning" => "50",
                "connected-users_critical" => "100",
                "sga-data-buffer-hit-ratio_warning" => "98:",
                "sga-data-buffer-hit-ratio_critical" => "95:",
                "sga-library-cache-hit-ratio_warning" => "98:",
                "sga-library-cache-hit-ratio_critical" => "95:",
                "sga-dictionary-cache-hit-ratio_warning" => "98:",
                "sga-dictionary-cache-hit-ratio_critical" => "95:",
                "sga-latches-hit-ratio_warning" => "98:",
                "sga-latches-hit-ratio_critical" => "95:",
                "sga-shared-pool-reload-ratio_warning" => "1",
                "sga-shared-pool-reload-ratio_critical" => "10",
                "sga-shared-pool-free_warning" => "10:",
                "sga-shared-pool-free_critical" => "5:",
                "pga-in-memory-sort-ratio_warning" => "99:",
                "pga-in-memory-sort-ratio_critical" => "90:",
                "soft-parse-ratio_warning" => "98:",
                "soft-parse-ratio_critical" => "90:",
                "retry-ratio_warning" => "1",
                "retry-ratio_critical" => "10",
                "redo-io-traffic_warning" => "100",
                "redo-io-traffic_critical" => "200",
                "roll-header-contention_warning" => "1",
                "roll-header-contention_critical" => "2",
                "roll-block-contention_warning" => "1",
                "roll-block-contention_critical" => "2",
                "roll-hit-ratio_warning" => "99:",
                "roll-hit-ratio_critical" => "98:",
                "roll-wraps_warning" => "1",
                "roll-wraps_critical" => "100",
                "roll-extends_warning" => "1",
                "roll-extends_critical" => "100",
                "flash-recovery-area-usage_warning" => "90",
                "flash-recovery-area-usage_critical" => "98",
            ));

            $select_options =[
                "Connection Time" => "connection-time",
                "Connected Users" => "connected-users",
                "SGA Data Buffer Hit Ratio" => "sga-data-buffer-hit-ratio",
                "SGA Library Cache Hit Ratio" => "sga-library-cache-hit-ratio",
                "SGA Dictionary Cache Hit Ratio" => "sga-dictionary-cache-hit-ratio",
                "SGA Shared Pool Reload Ratio" => "sga-shared-pool-reload-ratio",
                "SGA Shared Pool Free" => "sga-shared-pool-free",
                "PGA In Memory Sort Ratio" => "pga-in-memory-sort-ratio",
                "Soft Parse Ratio" => "soft-parse-ratio",
                "Retry Ratio" => "retry-ratio",
                "Redo I/O Traffic" => "redo-io-traffic",
                "Roll Header Contention" => "roll-header-contention",
                "Roll Block Contention" => "roll-block-contention",
                "Roll Hit Ratio" => "roll-hit-ratio",
                "Roll Wraps" => "roll-wraps",
                "Roll Extends" => "roll-extends",
                "Flash Recovery Area Usage" => "flash-recovery-area-usage",
                "SGA Latches Hit Ratio" => "sga-latches-hit-ratio",
            ];

            $service_tooltips = [
                "connection-time" => "Monitor amount time it takes to connect to the Oracle Server.",
                "connected-users" => "Monitor amount of connected users.",
                "sga-data-buffer-hit-ratio" => "Monitor the SGA Data Buffer.",
                "sga-library-cache-hit-ratio" => "Monitor the Library Cache.",
                "sga-dictionary-cache-hit-ratio" => "Monitor the SGA Dictionary.",
                "sga-shared-pool-reload-ratio" => "Monitor the SGA Shared Pool.",
                "sga-shared-pool-free" => "Monitor the SGA Shared Pool.",
                "pga-in-memory-sort-ratio" => "Monitor the PGA Memory.",
                "soft-parse-ratio" => "Monitor the amount of soft parses.",
                "retry-ratio" => "Monitor redo buffer retries.",
                "redo-io-traffic" => "Monitor the amount of I/O traffic from redos.",
                "roll-header-contention" => "Monitor contention for writes for the roll header.",
                "roll-block-contention" => "Monitor the roll block contention.",
                "roll-hit-ratio" => "Monitor the roll hit.",
                "roll-wraps" => "Monitor the roll wraps.",
                "roll-extends" => "Monitor the roll extends.",
                "flash-recovery-area-usage" => "Monitor the flash recovery area.",
                "sga-latches-hit-ratio" => "Monitor SGA Latches.",
            ];

            $services_serial = grab_array_var($inargs, "services_serial");

            if ($services_serial != "") {
                $services = json_decode(base64_decode($services_serial), true);
            }

            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial");

            if ($serviceargs_serial != "") {
                $serviceargs = json_decode(base64_decode($serviceargs_serial), true);
            }

            // Build Services Multi select HTML
            $service_list = '';
            $services_array = [];
            foreach ($select_options as $name => $service) {
                $name = encode_form_val($name);
                $safe_name = $service;
                $services_array[$name] = $service;
                $selected = '';
                if (isset($services[$service]) && $services[$service] == 'on'){ $selected = ' selected'; }
                $service_list .= "<option value='$safe_name' $selected>$name</option>";
            }

            $service_select_html = '<select name="services-select[]" id="services-select" multiple  class="form form-control metrics-select multiselect form-select">';
            $service_select_html .= $service_list;
            $service_select_html .= '</select>';

            ########################################################################################
            # Load the html
            # - The html needs to end up in the $output string, so use ob_start() and ob_get_clean()
            #   to load the PHP from the Step2 file into the $output string.
            ########################################################################################
            ob_start();
            include __DIR__.'/steps/step2.php';
            $output = ob_get_clean();

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $hostname = grab_array_var($inargs, "hostname");
            $hostname = nagiosccm_replace_user_macros($hostname);
            $port = grab_array_var($inargs, "port", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");

            $services = grab_array_var($inargs, "services", array());
            $serviceargs = grab_array_var($inargs, "serviceargs", array());

            $sid = grab_array_var($inargs, "sid", "");

            // Check for errors
            $errors = 0;
            $errmsg = array();

            if (is_valid_host_name($hostname) == false) {
                $errmsg[$errors++] = "Invalid host name.";
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $hostname = grab_array_var($inargs, "hostname");
            $port = grab_array_var($inargs, "port", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $sid = grab_array_var($inargs, "sid", "");
            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");

            $output = '

        <input type="hidden" name="ip_address" value="' . encode_form_val($address) . '">
        <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '">
        <input type="hidden" name="port" value="' . encode_form_val($port) . '">
        <input type="hidden" name="username" value="' . encode_form_val($username) . '">
        <input type="hidden" name="password" value="' . encode_form_val($password) . '">
        <input type="hidden" name="services_serial" value="' . base64_encode(json_encode($services)) . '">
        <input type="hidden" name="serviceargs_serial" value="' . base64_encode(json_encode($serviceargs)) . '">
        <input type="hidden" name="sid" value="' . encode_form_val($sid) . '">
';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:


            $output = '
            ';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:

            $hostname = grab_array_var($inargs, "hostname", "");
            $address = grab_array_var($inargs, "ip_address", "");
            $hostaddress = $address;
            $port = grab_array_var($inargs, "port", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");

            $services_serial = grab_array_var($inargs, "services_serial", "");
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", "");
            $sid = grab_array_var($inargs, "sid", "");
            $services = json_decode(base64_decode($services_serial), true);
            $serviceargs = json_decode(base64_decode($serviceargs_serial), true);

            // save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr["hostname"] = $hostname;
            $meta_arr["ip_address"] = $address;
            $meta_arr["port"] = $port;
            $meta_arr["username"] = $username;
            $meta_arr["password"] = $password;
            $meta_arr["services"] = $services;
            $meta_arr["serviceargs"] = $serviceargs;
            $meta_arr["sid"] = $sid;
            save_configwizard_object_meta($wizard_name, $hostname, "", $meta_arr);
            $objs = array();

            if (!host_exists($hostname)) {
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_oracleserverspace_host",
                    "host_name" => $hostname,
                    "address" => $hostaddress,
                    "icon_image" => "oracle.png",
                    "statusmap_image" => "oracle.png",
                    "_xiwizard" => $wizard_name,
                );
            }

            // common plugin opts
            if (have_value($sid) == false) {
                $commonopts = "--connect '{$address}:{$port}' --username '{$username}' --password '{$password}' ";
                $add_to_description = "";
            } else {
                $commonopts = "--connect '{$address}:{$port}/{$sid}' --username '{$username}' --password '{$password}' ";
                $add_to_description = $sid . " ";
            }

            foreach ($services as $svcvar => $svcval) {

                $pluginopts = "";
                $pluginopts .= $commonopts;

                switch ($svcvar) {

                    case "connection-time":

                        $pluginopts .= "--mode connection-time  --warning " . $serviceargs["connection-time_warning"] . " --critical " . $serviceargs["connection-time_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Connection Time",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "connected-users":

                        $pluginopts .= "--mode connected-users  --warning " . $serviceargs["connected-users_warning"] . " --critical " . $serviceargs["connected-users_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Connected Users",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "sga-data-buffer-hit-ratio":

                        $pluginopts .= "--mode sga-data-buffer-hit-ratio  --warning " . $serviceargs["sga-data-buffer-hit-ratio_warning"] . " --critical " . $serviceargs["sga-data-buffer-hit-ratio_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "SGA Data Buffer Hit Ratio",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "sga-library-cache-hit-ratio":

                        $pluginopts .= "--mode sga-library-cache-gethit-ratio  --warning " . $serviceargs["sga-library-cache-hit-ratio_warning"] . " --critical " . $serviceargs["sga-library-cache-hit-ratio_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "SGA Library Cache Hit Ratio",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;


                    case "sga-dictionary-cache-hit-ratio":

                        $pluginopts .= "--mode sga-dictionary-cache-hit-ratio  --warning " . $serviceargs["sga-dictionary-cache-hit-ratio_warning"] . " --critical " . $serviceargs["sga-dictionary-cache-hit-ratio_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "SGA Dictionary Cache Hit Ratio",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "sga-latches-hit-ratio":

                        $pluginopts .= "--mode sga-latches-hit-ratio  --warning " . $serviceargs["sga-latches-hit-ratio_warning"] . " --critical " . $serviceargs["sga-latches-hit-ratio_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "SGA Latch Hit Ratio",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "sga-shared-pool-reload-ratio":

                        $pluginopts .= "--mode sga-shared-pool-reload-ratio  --warning " . $serviceargs["sga-shared-pool-reload-ratio_warning"] . " --critical " . $serviceargs["sga-shared-pool-reload-ratio_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "SGA Shared Pool Reload Ratio",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "sga-shared-pool-free":

                        $pluginopts .= "--mode sga-shared-pool-free  --warning " . $serviceargs["sga-shared-pool-free_warning"] . " --critical " . $serviceargs["sga-shared-pool-free_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "SGA Shared Pool Free",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "pga-in-memory-sort-ratio":

                        $pluginopts .= "--mode pga-in-memory-sort-ratio  --warning " . $serviceargs["pga-in-memory-sort-ratio_warning"] . " --critical " . $serviceargs["pga-in-memory-sort-ratio_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "PGA In Memory Sort Ratio",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "soft-parse-ratio":

                        $pluginopts .= "--mode soft-parse-ratio  --warning " . $serviceargs["soft-parse-ratio_warning"] . " --critical " . $serviceargs["soft-parse-ratio_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Soft Parse Ratio",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "retry-ratio":

                        $pluginopts .= "--mode retry-ratio  --warning " . $serviceargs["retry-ratio_warning"] . " --critical " . $serviceargs["retry-ratio_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Retry Ratio",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "redo-io-traffic":

                        $pluginopts .= "--mode redo-io-traffic  --warning " . $serviceargs["redo-io-traffic_warning"] . " --critical " . $serviceargs["redo-io-traffic_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Redo I/O Traffic",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "roll-header-contention":

                        $pluginopts .= "--mode roll-header-contention  --warning " . $serviceargs["roll-header-contention_warning"] . " --critical " . $serviceargs["roll-header-contention_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Roll Header Contention",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "roll-block-contention":

                        $pluginopts .= "--mode roll-block-contention  --warning " . $serviceargs["roll-block-contention_warning"] . " --critical " . $serviceargs["roll-block-contention_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Roll Block Contention",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "roll-hit-ratio":

                        $pluginopts .= "--mode roll-hit-ratio  --warning " . $serviceargs["roll-hit-ratio_warning"] . " --critical " . $serviceargs["roll-hit-ratio_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Roll Hit Ratio",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "roll-wraps":

                        $pluginopts .= "--mode roll-wraps --warning " . $serviceargs["roll-wraps_warning"] . " --critical " . $serviceargs["roll-wraps_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Roll Wraps",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "roll-extends":

                        $pluginopts .= "--mode roll-extends --warning " . $serviceargs["roll-extends_warning"] . " --critical " . $serviceargs["roll-extends_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Roll Extends",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "flash-recovery-area-usage":

                        $pluginopts .= "--mode flash-recovery-area-usage  --warning " . $serviceargs["flash-recovery-area-usage_warning"] . " --critical " . $serviceargs["flash-recovery-area-usage_critical"] . "";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $add_to_description . "Flash Recovery Area Usage",
                            "use" => "xiwizard_oracleserverspace_service",
                            "check_command" => "check_xi_oracleserverspace!" . $pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    default:
                        break;
                }
            }

            //echo "OBJECTS:<BR>";
            //print_r($objs);
            //exit();

            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            break;

        default:
            break;
    }

    return $output;
}
