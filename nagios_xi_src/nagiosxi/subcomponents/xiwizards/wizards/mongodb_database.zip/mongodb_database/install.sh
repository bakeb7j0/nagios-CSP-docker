#!/bin/bash

pip install --upgrade pymongo
exit 0
