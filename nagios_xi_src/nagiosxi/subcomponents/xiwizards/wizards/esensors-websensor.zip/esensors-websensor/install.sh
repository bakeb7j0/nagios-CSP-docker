#!/bin/bash

# Build plugin
if [ -f /usr/local/nagiosxi/html/includes/configwizards/esensors-websensor/plugins/check_em08.c ]; then
	gcc /usr/local/nagiosxi/html/includes/configwizards/esensors-websensor/plugins/check_em08.c -o /usr/local/nagios/libexec/check_em08
fi
