<?php 
include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// Initialization stuff
pre_init();
init_session();
// Grab GET or POST variables and pre-reqs
grab_request_vars();
check_prereqs();
check_authentication(false);

hyperv_ajax_validate_instance_name();
// NCPA doesn't have to have a valid certificate, and it's not the same site as XI,
// so we won't be able to access it with AJAX directly.
function hyperv_ajax_validate_instance_name() {

	header("Content-Type: application/json");

	$perf_object = grab_request_var('perf_object');
	$instance_name = grab_request_var('instance_name');
	$perf_counter = grab_request_var('perf_counter');
	$ip_address = grab_request_var('ip_address');
	$token = grab_request_var('token');
	$port = intval(grab_request_var('port'));
	$factor = grab_request_var('factor', '0');

	$port = strval(intval($port));
	$factor = strval(intval($factor));

	// Validate ip address
	if (!filter_var($ip_address, FILTER_VALIDATE_IP)) {
		print 'Invalid IP address';
		return;
	}

	$performance_counter = str_replace('?', '', "$perf_object($instance_name)/$perf_counter");
	$ncpa_url = "https://$ip_address:$port/api/windowscounters/$performance_counter?token=$token&sleep=1&factor=$factor";
	$ncpa_url = escapeshellarg($ncpa_url);

    $cmd = "curl $ncpa_url -g -f -k --connect-timeout 10";

    $ret = 0;
    exec($cmd, $data, $ret);
    $data = implode("", $data);
    print $data;
}
