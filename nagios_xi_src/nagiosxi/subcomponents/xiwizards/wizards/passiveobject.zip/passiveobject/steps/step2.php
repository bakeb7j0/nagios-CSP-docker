    <!--                                   -->
    <!-- The initial data set from Step 1. -->
    <!--                                   -->
    <input type="hidden" id="hostname" name="hostname" value="<?= encode_form_val($hostname) ?>">
    <input type="hidden" id="operation" name="operation" value="<?= encode_form_val($operation) ?>">
    <input type="hidden" id="selectedhostconfig" name="selectedhostconfig" value="<?= encode_form_val($selectedhostconfig) ?>">
    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
    <div class="container m-0 g-0">
    <input type="hidden" name="securitycheck" value="<?= encode_form_val($securitycheck) ?>">
    <input type="hidden" name="isvolatile" value="<?= encode_form_val($isvolatile) ?>">
    <input type="hidden" name="statestalking" value="<?= encode_form_val($statestalking) ?>">
    <input type="hidden" name="hosts_serial" value="<?= base64_encode(json_encode($hosts)) ?>">

    <h2><?= _('Hosts') ?></h2>
    <p><?= _('This wizard will automatically create missing object definitions for the following hosts and their associated services:') ?></p>
    <div class="border-block-small">

<?php
    foreach ($hosts as $hn => $ts) {
        echo($hn."<BR>");
    }
?>
    </div>
    </div> <!-- container -->

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
