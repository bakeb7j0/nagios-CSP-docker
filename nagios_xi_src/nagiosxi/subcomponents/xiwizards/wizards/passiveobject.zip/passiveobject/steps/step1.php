    <div class="container m-0 g-0">
        <!--                         -->
        <!-- The configuration form. -->
        <!--                         -->
        <div id="configForm">
            <p>
                <?= _('This wizard can only be used when configuring passive hosts and services through the') ?> <a href="../admin/missingobjects.php"><?= _('Unconfigured Objects') ?></a> page.
            </p>
        </div> <!-- config -->
    </div> <!-- container -->

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
