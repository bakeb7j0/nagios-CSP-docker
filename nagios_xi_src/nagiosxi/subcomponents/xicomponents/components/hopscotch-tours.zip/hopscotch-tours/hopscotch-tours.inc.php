<?php
//
// Hopscotch Tours
// Copyright (c) 2023 Nagios Enterprises, LLC. All rights reserved.
// 

require_once(dirname(__FILE__) . '/../componenthelper.inc.php');

$hop_component_name = "hopscotch-tours";
hop_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function hop_component_init()
{
    global $hop_component_name;

    $args = array(
        COMPONENT_NAME => $hop_component_name,
        COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
        COMPONENT_DESCRIPTION => _("Displays and tracks Nagios XI tours for each user."),
        COMPONENT_TITLE => _("Nagios XI Tours"),
        COMPONENT_VERSION => '1.0.0'
    );

    register_component($hop_component_name, $args);
}