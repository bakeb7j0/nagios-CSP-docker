#!/bin/bash

# This script takes the JSX/React javascript and compiles it into a static site.

BASEDIR=$(dirname $(readlink -f $0))
# We define a base here because we're nesting this React project inside of Nagios XI proper.
pushd $BASEDIR/alert-history-dashlet
yarn
popd
