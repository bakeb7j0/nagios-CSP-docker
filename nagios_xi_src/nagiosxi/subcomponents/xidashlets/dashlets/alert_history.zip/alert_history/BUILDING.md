BUILDING
========

This project uses `yarn` for its build process. As of 2024-01-18, we're using the following manually-installed dependencies:

NodeJS (via nodejs.org):
```
[root@localhost alert_history]# node --version
v20.10.0
```

NPM (via NodeJS, then self-upgrade):
```
[root@localhost alert_history]# npm --version
10.2.5
```

yarn (via `npm install -g yarn`)
```
[root@localhost alert_history]# yarn --version
1.22.21
```

tsc (via `npm install -g typescript`)
```
[root@localhost alert_history]# tsc --version
Version 5.3.3
```

Once you have the first four dependencies installed, you should be able to do the following:

```
./setup.sh
./build.sh
```

After making changes to the React project, you should be able to rerun the just the build script:

```
./build.sh
```
