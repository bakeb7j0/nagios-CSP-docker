import { useState } from 'react'
//import { ResponsiveCalendar } from '@nivo/calendar'
//import reactLogo from './assets/react.svg'
//import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  const params = new URLSearchParams(window.location.href);

  let ajaxPath = window.location.pathname;
  ajaxPath = ajaxPath.slice(0, ajaxPath.lastIndexOf('/') + 1) + "ajax.php?nsp=" + params.get('nsp');

  let ajaxContainerID = "alert_history-ajax-" + params.get('container');

  let ajaxCall = new XMLHttpRequest();
  ajaxCall.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      let ajaxTextElement = document.getElementById(ajaxContainerID);
      if (ajaxTextElement !== null) {
        ajaxTextElement.innerHTML = ajaxCall.responseText;
      }
    }
  }

  ajaxCall.open("GET", ajaxPath);
  ajaxCall.send();

  return (
    <>
      <div id={ajaxContainerID}>
        <h1>Loading...</h1>
      </div>

      <h1>This is technically a React app</h1>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <button onClick={() => setCount((count) => count + 1)}>
          The AJEAX path is {ajaxPath}
        </button>
      </div>
    </>
  )
}

export default App
