// Set colors for current status bar (not background zones)
// const critColor = '#FF795F'; //service status page red
const critColor = '#F96c59';  
const warnColor = '#FEFF5F';  //service status page yellow
const okColor = '#5CDF45';    //monitoring engine graph

$('.dashletconfigure').click(function() {
  $('.dashlet-modify-menu').querySelector('div.dashlet-modify-menu').toggle();
});

function setstrokewidth(id, num) {
  document.querySelector('#dashlet-'+id+' svg circle').style.setProperty('stroke-width',num);
}

function updategauge(id, args, host, service){
  document.querySelector('#dashlet-'+id).querySelector(' .gaugetext p#serviceName').innerHTML = args['label'];
  document.querySelector('#dashletcontainer-'+id+' .dashlettopbox .dashlettitle').innerHTML += ' - ' + host+' - '+ service+' - '+args['label'];
  setvalhelper('#dashlet-'+id, args['current'],args['warn'],args['crit'], args['max'], args['uom']);
}
  
function setvalhelper(id, num, war, crt, max, unit) {  
  const gaugedashlet = document.querySelector(id);
  const r = gaugedashlet.querySelector('svg circle:nth-child(4)').getAttribute('r');

  if(parseInt(war) > parseInt(crt)){
    const tmp = war;
    war = crt;
    crt = tmp;
  }

  var span = document.querySelector(id).querySelector('.gaugetext h2 span')
  span.innerHTML = unit;
  document.querySelector(id).querySelector('.gaugetext h2').innerHTML = num;
  document.querySelector(id).querySelector('.gaugetext h2').style.fontSize = (2.5-(0.25*(Math.max(0,num.toString().length-4))))+'em';
  $(id+' .gaugetext h2').append(span);
  
  //adjust values into percentages
  num = num*100/max;
  war = war*100/max;
  crt = crt*100/max;
  
  //change color based on warning/critical
  if (parseInt(num) >= parseInt(crt)){ //critical
    setpercentcolor(id,critColor);
  } else if (parseInt(num) >= parseInt(war)){ //warning
    setpercentcolor(id,warnColor);
  } else { //ok
    setpercentcolor(id,okColor);
  }

  document.querySelector(id).style.setProperty('--num',num);
  
  //definition of stroke -- necessary for some browsers
  gaugedashlet.querySelector(id+' svg circle:nth-child(4)').style['stroke-dashoffset'] = (arclen(num, r));
  
  //warning
  gaugedashlet.querySelector(id+' svg circle:nth-child(3)').style['stroke-dashoffset'] = (arclen(crt-war, r));
  gaugedashlet.querySelector(id+' svg circle:nth-child(3)').style['transform'] = 'translate(10px, 10px) rotate('+p2d(war)+'deg)';
  
  //critical
  gaugedashlet.querySelector(id+' svg circle:nth-child(2)').style['stroke-dashoffset'] = (arclen(100-crt, r));
  gaugedashlet.querySelector(id+' svg circle:nth-child(2)').style['transform'] = 'translate(10px, 10px) rotate('+(p2d(crt)+0.35)+'deg)'; // add 0.35 deg to compensate for machine error causing overlap

  if(num > 100) { // current value > max value, gauge will not work properly
    gaugedashlet.querySelector(id+' .gaugetext p#value').style.setProperty('display', 'none');
    gaugedashlet.querySelector(id+' svg circle:nth-child(4)').style['stroke-dashoffset'] = (arclen(100, r));
  } else {
    gaugedashlet.querySelector(id+' .gaugetext p#value').innerHTML = (num).toFixed(2);
  }
} 

// percent to degrees
function p2d(num){
  return 3.6*num;
}

//converts percent of circle to dasharray length
function arclen(num, r){
  return (r2pi(r)- (r2pi(r) * (num/100)));
}

//find how long an arc that completes a full circle should be based on circle radius
function r2pi(r){
  return 2*Math.PI*r;
}

function setpercentcolor(id,color){
  document.querySelector(id+' svg circle:nth-child(4)').style.setProperty('--color',color);
  document.querySelector(id+' .gaugetext > *').style.setProperty('--color', colorsubdue(color,2));
}

function colorsubdue(color, degree){
  //subdue the color for the center stuff
  color = color.substring(1, color.length).toLowerCase(); //remove # and set to lowercase
  
  numlist = '0123456789abcdef';
  numlist = '0'.repeat(degree) + numlist;
  
  for (i=0; i<color.length; i++){
    color = color.substring(0,i) + 
    numlist[numlist.indexOf(color[i], degree) - degree] + 
    color.substring(i+1,color.length);
  }
  return '#'+color;
}

function hidezones(id){
  document.querySelector(id+' svg circle:nth-child(3)').style['display'] = 'none';
  document.querySelector(id+' svg circle:nth-child(2)').style['display'] = 'none';
}
function showzones(id){
  document.querySelector(id+' svg circle:nth-child(3)').style['display'] = 'block';
  document.querySelector(id+' svg circle:nth-child(2)').style['display'] = 'block';
}

function hidepercent(id){
  document.querySelector(id+' .gaugetext p#value').style['display'] = 'none';
  document.querySelector(id+' .gaugetext p#value').style['display'] = 'none';
}

function showpercent(id){
  document.querySelector(id+' .gaugetext p#value').style['display'] = 'block';
  document.querySelector(id+' .gaugetext p#value').style['display'] = 'block';
}

function hidetickmarks(id){
  document.querySelector(id+' svg .war').style['display'] = 'none';
  document.querySelector(id+' svg .crt').style['display'] = 'none';
}
