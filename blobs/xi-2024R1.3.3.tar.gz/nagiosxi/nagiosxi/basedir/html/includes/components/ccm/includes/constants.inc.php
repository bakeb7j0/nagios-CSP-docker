<?php

// Version information (also used to create fresh CCS/Javascript includes)
define('CCMVERSION', '3.1.9');
define('VERSION', 319);

// Directory location constants 
define('INCDIR', BASEDIR.'includes/'); 
define('TPLDIR', BASEDIR.'page_templates/'); 
define('CLASSDIR', BASEDIR.'classes/'); 
