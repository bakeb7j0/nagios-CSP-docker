<?php
//
// Component Helper Functions
// Copyright (c) 2008-2018 Nagios Enterprises, LLC. All rights reserved.
//

$thedir = dirname(__FILE__) . "/..";

require_once($thedir . '/common.inc.php');
require_once($thedir . '/utilsl.inc.php');
require_once($thedir . '/utils-components.inc.php');
