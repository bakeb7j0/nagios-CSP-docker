$(document).ready(function() {
var p = '<p>Nagios Graph Explorer</p>';
$("#visContainer").append(p);
}); 