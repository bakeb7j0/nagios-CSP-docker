<?php
//
// Backend Handler Includes
// Copyright (c) 2008-2020 Nagios Enterprises, LLC. All rights reserved.
//

// Standard return handlers
require_once(dirname(__FILE__) . '/handler-auditlog.inc.php');
require_once(dirname(__FILE__) . '/handler-misc.inc.php');
require_once(dirname(__FILE__) . '/handler-objects.inc.php');
require_once(dirname(__FILE__) . '/handler-perms.inc.php');
require_once(dirname(__FILE__) . '/handler-reports.inc.php');
require_once(dirname(__FILE__) . '/handler-status.inc.php');
