title: check_ldaps
parent: Manpages
---
#Nagios check_ldaps Plugin

    check_ldaps v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Didi Rieder (adrieder@sbox.tu-graz.ac.at)
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>



    Usage:
     check_ldaps (-H <host>|-U <uri>) -b <base_dn> [-p <port>] [-a <attr>] [-D <binddn>]
           [-P <password>] [-w <warn_time>] [-c <crit_time>] [-t timeout] [-A <age>]
           [-2|-3] [-4|-6]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 389)
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -a, --attr=ATTRIBUTE
        ldap attribute to search (default: "(objectclass=*)"
     -b, --base=BASE
        ldap base (eg. ou=my unit, o=my org, c=at
     -D, --bind=DN
        ldap bind DN (if required)
     -P, --pass=PASSWORD
        ldap password (if required)
     -T, --starttls
        use starttls mechanism introduced in protocol version 3
     -S, --ssl
        use ldaps (ldap v2 ssl method). this also sets the default port to 636
     -A, --age=INTEGER[,INTEGER]
        Minimum number of days a certificate has to be valid
     -2, --ver2
        use ldap protocol version 2
     -3, --ver3
        use ldap protocol version 3
        (default protocol version: 2)
     -w, --warning=DOUBLE
        Response time to result in warning status (seconds)
     -c, --critical=DOUBLE
        Response time to result in critical status (seconds)
     -W, --warn-entries=INTEGER
        Number of found entries to result in warning status
     -C, --crit-entries=INTEGER
        Number of found entries to result in critical status
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    Notes:
     If this plugin is called via 'check_ldaps', method 'STARTTLS' will be
     implied (using default port 389) unless --port=636 is specified. In that case
     'SSL on connect' will be used no matter how the plugin was called.
     This detection is deprecated, please use 'check_ldap' with the '--starttls' or '--ssl' flags
     to define the behaviour explicitly instead.
     The parameters --warn-entries and --crit-entries are optional.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

