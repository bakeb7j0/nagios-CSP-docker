title: check_mailq
parent: Manpages
---
#Nagios check_mailq Plugin

    check_mailq v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.
    Copyright (c) 2002 Subhendu Ghosh/Carlos Canau/Benjamin Schmid

    Usage: check_mailq -w <warn> -c <crit> [-W <warn>] [-C <crit>] [-M <MTA>] [-t <timeout>] [-s] [-d <CONFIGDIR>] [-v]

       Checks the number of messages in the mail queue (supports multiple sendmail queues, qmail)
       Feedback/patches to support non-sendmail mailqueue welcome

    -w (--warning)   = Min. number of messages in queue to generate warning
    -c (--critical)  = Min. number of messages in queue to generate critical alert ( w < c )
    -W (--Warning)   = Min. number of messages for same domain in queue to generate warning
    -C (--Critical)  = Min. number of messages for same domain in queue to generate critical alert ( W < C )
    -t (--timeout)   = Plugin timeout in seconds (default = 15)
    -M (--mailserver) = [ sendmail | qmail | postfix | exim | nullmailer | opensmtpd ] (default = autodetect)
    -h (--help)
    -V (--version)
    -v (--verbose)   = debugging output


    Note: -w and -c are required arguments.  -W and -C are optional.
     -W and -C are applied to domains listed on the queues - both FROM and TO. (sendmail)
     -W and -C are applied message not yet preproccessed. (qmail)
     This plugin tries to autodetect which mailserver you are running,
     you can override the autodetection with -M.
     This plugin uses the system mailq command (sendmail) or qmail-stat (qmail)
     to look at the queues. Mailq can usually only be accessed by root or 
     a TrustedUser. You will have to set appropriate permissions for the plugin to work.


    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org. Please include version information with all
    correspondence (when possible, use output from the --version option of the
    plugin itself).
