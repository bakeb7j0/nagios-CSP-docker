title: check_ircd
parent: Manpages
---
#Nagios check_ircd Plugin

    check_ircd v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.
    Copyright (c) 2000 Richard Mayhew/Karl DeBisschop

    Perl Check IRCD plugin for Nagios

    Usage: check_ircd -H <host> [-w <warn>] [-c <crit>] [-p <port>]

    -H, --hostname=HOST
       Name or IP address of host to check
    -w, --warning=INTEGER
       Number of connected users which generates a warning state (Default: 50)
    -c, --critical=INTEGER
       Number of connected users which generates a critical state (Default: 100)
    -p, --port=INTEGER
       Port that the ircd daemon is running on <host> (Default: 6667)
    -v, --verbose
       Print extra debugging information
