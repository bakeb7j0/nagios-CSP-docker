title: check_by_ssh
parent: Manpages
---
#Nagios check_by_ssh Plugin

    check_by_ssh v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Karl DeBisschop <kdebisschop@users.sourceforge.net>
    Copyright (c) 2000- Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin uses SSH to execute commands on a remote host

    Usage:
     check_by_ssh -H <host> -C <command> [-fqv] [-1|-2] [-4|-6]
           [-S [lines]] [-E [lines]] [-t timeout] [-i identity]
           [-l user] [-n name] [-s servicelist] [-O outputfile]
           [-p port] [-o ssh-option] [-F configfile]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: none)
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -1, --proto1
        tell ssh to use Protocol 1 [optional]
     -2, --proto2
        tell ssh to use Protocol 2 [optional]
     -S, --skip-stdout[=n]
        Ignore all or (if specified) first n lines on STDOUT [optional]
     -E, --skip-stderr[=n]
        Ignore all or (if specified) first n lines on STDERR [optional]
     -f
        tells ssh to fork rather than create a tty [optional]. This will always return OK if ssh is executed
     -C, --command='COMMAND STRING'
        command to execute on the remote machine
     -l, --logname=USERNAME
        SSH user name on remote host [optional]
     -i, --identity=KEYFILE
        identity of an authorized key [optional]
     -O, --output=FILE
        external command file for nagios [optional]
     -s, --services=LIST
        list of nagios service names, separated by ':' [optional]
     -n, --name=NAME
        short name of host in nagios configuration [optional]
     -o, --ssh-option=OPTION
        Call ssh with '-o OPTION' (may be used multiple times) [optional]
     -F, --configfile
        Tell ssh to use this configfile [optional]
     -q, --quiet
        Tell ssh to suppress warning and diagnostic messages [optional]
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

     The most common mode of use is to refer to a local identity file with
     the '-i' option. In this mode, the identity pair should have a null
     passphrase and the public key should be listed in the authorized_keys
     file of the remote host. Usually the key will be restricted to running
     only one command on the remote server. If the remote SSH server tracks
     invocation arguments, the one remote program may be an agent that can
     execute additional commands as proxy

     To use passive mode, provide multiple '-C' options, and provide
     all of -O, -s, and -n options (servicelist order must match '-C'options)

    Examples:
     $ check_by_ssh -H localhost -n lh -s c1:c2:c3 -C uptime -C uptime -C uptime -O /tmp/foo
     $ cat /tmp/foo
     [1080933700] PROCESS_SERVICE_CHECK_RESULT;flint;c1;0; up 2 days
     [1080933700] PROCESS_SERVICE_CHECK_RESULT;flint;c2;0; up 2 days
     [1080933700] PROCESS_SERVICE_CHECK_RESULT;flint;c3;0; up 2 days

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

