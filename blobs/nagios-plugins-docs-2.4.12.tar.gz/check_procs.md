title: check_procs
parent: Manpages
---
#Nagios check_procs Plugin

    check_procs v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    Checks all processes and generates WARNING or CRITICAL states if the specified
    metric is outside the required threshold ranges. The metric defaults to number
    of processes.  Search filters can be applied to limit the processes to check.


    Usage:
    check_procs -w <range> -c <range> [-m metric] [-s state] [-p ppid] [-j jid]
     [-u user] [-r rss] [-z vsz] [-P %cpu] [-a argument-array]
     [-C command] [-X process_to_exclude] [-k] [-t timeout] [-v]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -w, --warning=RANGE
       Generate warning state if metric is outside this range
     -c, --critical=RANGE
       Generate critical state if metric is outside this range
     -m, --metric=TYPE
      Check thresholds against metric. Valid types:
      PROCS   - number of processes (default)
      VSZ     - virtual memory size
      RSS     - resident set memory size
      CPU     - percentage CPU
      ELAPSED - time elapsed in seconds
     -t, --timeout=INTEGER
        Seconds before plugin times out (default: 10)
     -v, --verbose
        Extra information. Up to 3 verbosity levels
     -T, --traditional
       Filter own process the traditional way by PID instead of /proc/pid/exe

    Filters:
     -s, --state=STATUSFLAGS
       Only scan for processes that have, in the output of `ps`, one or
       more of the status flags you specify (for example R, Z, S, RS,
       RSZDT, plus others based on the output of your 'ps' command).
     -p, --ppid=PPID
       Only scan for children of the parent process ID indicated.
     -j, --jid=JID
       Only scan for process running in jail which ID is JID.
     -z, --vsz=VSZ
       Only scan for processes with VSZ higher than indicated.
     -r, --rss=RSS
       Only scan for processes with RSS higher than indicated.
     -P, --pcpu=PCPU
       Only scan for processes with PCPU higher than indicated.
     -u, --user=USER
       Only scan for processes with user name or ID indicated.
     -a, --argument-array=STRING
       Only scan for processes with args that contain STRING.
     --ereg-argument-array=STRING
       Only scan for processes with args that contain the regex STRING.
     -C, --command=COMMAND
       Only scan for exact matches of COMMAND (without path).
     -X, --exclude-process
       Exclude processes which match this comma separated list
     -k, --no-kthreads
       Only scan for non kernel threads (works on Linux only).
     -g, --cgroup-hierarchy
       Only scan for processes belonging to STRING hierarchy (works on Linux only).

    Extra:
     --input-file=FILE
       Use FILE content instead of /bin/ps output.

    RANGEs are prefixed with @ and specified 'min:max' or 'min:' or ':max' (or 'max'). If
    specified 'max:min', a warning status will be generated if the
    count is inside the specified range

    This plugin checks the number of currently running processes and
    generates WARNING or CRITICAL states if the process count is outside
    the specified threshold ranges. The process count can be filtered by
    process owner, parent process PID, current state (e.g., 'Z'), or may
    be the total number of running processes

    Examples:
     check_procs -w @2:2 -c 2:1024 -C portsentry
      Warning if not two processes with command name portsentry.
      Critical if < 2 or > 1024 processes

     check_procs -c @1:1 -C bind -g /
      Critical if not one processes with command name bind belonging to root cgroup.

     check_procs -w 10 -a '/usr/local/bin/perl' -u root
      Warning alert if > 10 processes with command arguments containing
      '/usr/local/bin/perl' and owned by root

     check_procs -w 50000 -c 100000 --metric=VSZ
      Alert if VSZ of any processes over 50K or 100K

     check_procs -w 10 -c 20 --metric=CPU
      Alert if CPU of any processes over 10%% or 20%%

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

