title: check_fping
parent: Manpages
---
#Nagios check_fping Plugin

    check_fping v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Didi Rieder <adrieder@sbox.tu-graz.ac.at>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin will use the fping command to ping the specified host for a fast check
    Note that it is necessary to set the suid flag on fping.


    Usage:
     check_fping <host_address> -w limit -c limit [-b size] [-n number] [-T number] [-i number]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -H, --hostname=HOST
        name or IP Address of host to ping (IP Address bypasses name lookup, reducing system load)
     -w, --warning=THRESHOLD
        warning threshold pair
     -c, --critical=THRESHOLD
        critical threshold pair
     -b, --bytes=INTEGER
        size of ICMP packet (default: 56)
     -n, --number=INTEGER
        number of ICMP packets to send (default: 1)
     -T, --target-timeout=INTEGER
        Target timeout (ms) (default: fping's default for -t)
     -i, --interval=INTEGER
        Interval (ms) between sending packets (default: fping's default for -p)
     -S, --sourceip=HOST
        name or IP Address of sourceip
     -I, --sourceif=IF
        source interface name
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

     THRESHOLD is <rta>,<pl>%% where <rta> is the round trip average travel time (ms)
     which triggers a WARNING or CRITICAL state, and <pl> is the percentage of
     packet loss to trigger an alarm state.

     IPv4 is used by default. Specify -6 to use IPv6.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

