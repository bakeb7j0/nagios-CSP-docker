title: check_breeze
parent: Manpages
---
#Nagios check_breeze Plugin

    check_breeze v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.
    Copyright (c) 2000 Jeffrey Blank/Karl DeBisschop

    This plugin reports the signal strength of a Breezecom wireless equipment

    Usage: check_breeze -H <host> [-C community] -w <warn> -c <crit>

    -H, --hostname=HOST
       Name or IP address of host to check
    -C, --community=community
       SNMPv1 community (default public)
    -w, --warning=INTEGER
       Percentage strength below which a WARNING status will result
    -c, --critical=INTEGER
       Percentage strength below which a CRITICAL status will result

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org. Please include version information with all
    correspondence (when possible, use output from the --version option of the
    plugin itself).
