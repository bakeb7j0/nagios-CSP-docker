title: check_ntp
parent: Manpages
---
#Nagios check_ntp Plugin

    check_ntp v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2006 Sean Finney
    Copyright (c) 2006-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin checks the selected ntp server


    WARNING: check_ntp is deprecated. Please use check_ntp_peer or
    check_ntp_time instead.

    Usage:
     check_ntp -H <host> [-w <warn>] [-c <crit>] [-j <warn>] [-k <crit>] [-4|-6] [-v verbose] [-d <delay>]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 123)
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -w, --warning=THRESHOLD
        Offset to result in warning status (seconds)
     -c, --critical=THRESHOLD
        Offset to result in critical status (seconds)
     -j, --jwarn=THRESHOLD
        Warning threshold for jitter
     -k, --jcrit=THRESHOLD
        Critical threshold for jitter
     -d, --delay=INTEGER
        Delay between each packet (seconds)
     -z, --allow-zero-stratum
        Do not discard DNS servers which report a stratum of zero (0)
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    Notes:
     --delay is useful if you are triggering the anti-DOS for the
     NTP server and need to leave a bigger gap between queries
     See:
     https://www.nagios-plugins.org/doc/guidelines.html#THRESHOLDFORMAT
     for THRESHOLD format and examples.

    Examples:
     Normal offset check:
      ./check_ntp -H ntpserv -w 0.5 -c 1

     Check jitter too, avoiding critical notifications if jitter isn't available
     (See Notes above for more details on thresholds formats):
      ./check_ntp -H ntpserv -w 0.5 -c 1 -j -1:100 -k -1:200

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

    WARNING: check_ntp is deprecated. Please use check_ntp_peer or
    check_ntp_time instead.

