title: check_dummy
parent: Manpages
---
#Nagios check_dummy Plugin

    check_dummy v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 1999-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin will simply return the state corresponding to the numeric value
    of the <state> argument with optional text


    Usage:
     check_dummy <integer state> [optional text]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

