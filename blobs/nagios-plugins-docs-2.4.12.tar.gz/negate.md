title: negate
parent: Manpages
---
#Nagios negate Plugin

    negate v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2002-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    Negates the status of a plugin (returns OK for CRITICAL and vice-versa).
    Additional switches can be used to control which state becomes what.


    Usage:
    negate [-t timeout] [-Towcu STATE] [-s] <definition of wrapped plugin>

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     -t, --timeout=INTEGER
        Seconds before plugin times out (default: 11)
        Keep timeout longer than the plugin timeout to retain CRITICAL status.
     -T, --timeout-result=STATUS
        Custom result on Negate timeouts; see below for STATUS definition

     -o, --ok=STATUS
     -w, --warning=STATUS
     -c, --critical=STATUS
     -u, --unknown=STATUS
        STATUS can be 'OK', 'WARNING', 'CRITICAL' or 'UNKNOWN' without single
        quotes. Numeric values are accepted. If nothing is specified, permutes
        OK and CRITICAL.
     -s, --substitute
        Substitute output text as well. Will only substitute text in CAPITALS

    Examples:
     negate /usr/local/nagios/libexec/check_ping -H host
        Run check_ping and invert result. Must use full path to plugin
     negate -w OK -c UNKNOWN /usr/local/nagios/libexec/check_procs -a 'vi negate.c'
        This will return OK instead of WARNING and UNKNOWN instead of CRITICAL

    Notes:
     This plugin is a wrapper to take the output of another plugin and invert it.
     The full path of the plugin must be provided.
     If the wrapped plugin returns OK, the wrapper will return CRITICAL.
     If the wrapped plugin returns CRITICAL, the wrapper will return OK.
     Otherwise, the output state of the wrapped plugin is unchanged.

     Using timeout-result, it is possible to override the timeout behaviour or a
     plugin by setting the negate timeout a bit lower.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

