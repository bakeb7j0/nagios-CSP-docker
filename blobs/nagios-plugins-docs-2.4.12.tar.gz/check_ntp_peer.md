title: check_ntp_peer
parent: Manpages
---
#Nagios check_ntp_peer Plugin

    check_ntp_peer v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2006 Sean Finney
    Copyright (c) 2006-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin checks the selected ntp server


    Usage:
     check_ntp_peer -H <host> [-4|-6] [-w <warn>] [-c <crit>] [-W <warn>] [-C <crit>]
           [-j <warn>] [-k <crit>] [-v verbose]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 123)
     -q, --quiet
        Returns UNKNOWN instead of CRITICAL or WARNING if server isn't synchronized
     -w, --warning=THRESHOLD
        Offset to result in warning status (seconds)
     -c, --critical=THRESHOLD
        Offset to result in critical status (seconds)
     -W, --swarn=THRESHOLD
        Warning threshold for stratum of server's synchronization peer
     -C, --scrit=THRESHOLD
        Critical threshold for stratum of server's synchronization peer
     -j, --jwarn=THRESHOLD
        Warning threshold for jitter
     -k, --jcrit=THRESHOLD
        Critical threshold for jitter
     -m, --twarn=THRESHOLD
        Warning threshold for number of usable time sources ("truechimers")
     -n, --tcrit=THRESHOLD
        Critical threshold for number of usable time sources ("truechimers")
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    This plugin checks an NTP server independent of any commandline
    programs or external libraries.

    Notes:
     Use this plugin to check the health of an NTP server. It supports
     checking the offset with the sync peer, the jitter and stratum. This
     plugin will not check the clock offset between the local host and NTP
     server; please use check_ntp_time for that purpose.

     See:
     https://www.nagios-plugins.org/doc/guidelines.html#THRESHOLDFORMAT
     for THRESHOLD format and examples.

    Examples:
     Simple NTP server check:
      ./check_ntp_peer -H ntpserv -w 0.5 -c 1

     Check jitter too, avoiding critical notifications if jitter isn't available
     (See Notes above for more details on thresholds formats):
      ./check_ntp_peer -H ntpserv -w 0.5 -c 1 -j -1:100 -k -1:200

     Only check the number of usable time sources ("truechimers"):
      ./check_ntp_peer -H ntpserv -m @5 -n @3

     Check only stratum:
      ./check_ntp_peer -H ntpserv -W 4 -C 6

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

