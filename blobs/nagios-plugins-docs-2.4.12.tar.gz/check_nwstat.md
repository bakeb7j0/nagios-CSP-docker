title: check_nwstat
parent: Manpages
---
#Nagios check_nwstat Plugin

    check_nwstat v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin attempts to contact the MRTGEXT NLM running on a
    Novell server to gather the requested system information.


    Usage:
    check_nwstat -H host [-p port] [-v variable] [-w warning] [-c critical] [-t timeout]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 9999)
     -v, --variable=STRING
       Variable to check.  Valid variables include:
        LOAD1     = 1 minute average CPU load
        LOAD5     = 5 minute average CPU load
        LOAD15    = 15 minute average CPU load
        CSPROCS   = number of current service processes (NW 5.x only)
        ABENDS    = number of abended threads (NW 5.x only)
        UPTIME    = server uptime
        LTCH      = percent long term cache hits
        CBUFF     = current number of cache buffers
        CDBUFF    = current number of dirty cache buffers
        DCB       = dirty cache buffers as a percentage of the total
        TCB       = dirty cache buffers as a percentage of the original
        OFILES    = number of open files
            VMF<vol>  = MB of free space on Volume <vol>
            VMU<vol>  = MB used space on Volume <vol>
            VMP<vol>  = MB of purgeable space on Volume <vol>
            VPF<vol>  = percent free space on volume <vol>
            VKF<vol>  = KB of free space on volume <vol>
            VPP<vol>  = percent purgeable space on volume <vol>
            VKP<vol>  = KB of purgeable space on volume <vol>
            VPNP<vol> = percent not yet purgeable space on volume <vol>
            VKNP<vol> = KB of not yet purgeable space on volume <vol>
            LRUM      = LRU sitting time in minutes
            LRUS      = LRU sitting time in seconds
            DSDB      = check to see if DS Database is open
            DSVER     = NDS version
            UPRB      = used packet receive buffers
            PUPRB     = percent (of max) used packet receive buffers
            SAPENTRIES = number of entries in the SAP table
            SAPENTRIES<n> = number of entries in the SAP table for SAP type <n>
            TSYNC     = timesync status
            LOGINS    = check to see if logins are enabled
            CONNS     = number of currently licensed connections
            NRMH	= NRM Summary Status
            NRMP<stat> = Returns the current value for a NRM health item
            NRMM<stat> = Returns the current memory stats from NRM
            NRMS<stat> = Returns the current Swapfile stats from NRM
            NSS1<stat> = Statistics from _Admin:Manage_NSS\GeneralStats.xml
            NSS3<stat> = Statistics from _Admin:Manage_NSS\NameCache.xml
            NSS4<stat> = Statistics from _Admin:Manage_NSS\FileStats.xml
            NSS5<stat> = Statistics from _Admin:Manage_NSS\ObjectCache.xml
            NSS6<stat> = Statistics from _Admin:Manage_NSS\Thread.xml
            NSS7<stat> = Statistics from _Admin:Manage_NSS\AuthorizationCache.xml
            NLM:<nlm> = check if NLM is loaded and report version
                        (e.g. NLM:TSANDS.NLM)

     -w, --warning=INTEGER
        Threshold which will result in a warning status
     -c, --critical=INTEGER
        Threshold which will result in a critical status
     -o, --osversion
        Include server version string in results
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING

    Notes:
     - This plugin requres that the MRTGEXT.NLM file from James Drews' MRTG
       extension for NetWare be loaded on the Novell servers you wish to check.
       (available from http://www.engr.wisc.edu/~drews/mrtg/)
     - Values for critical thresholds should be lower than warning thresholds
       when the following variables are checked: VPF, VKF, LTCH, CBUFF, DCB, 
       TCB, LRUS and LRUM.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

