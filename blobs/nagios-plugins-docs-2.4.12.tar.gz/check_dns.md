title: check_dns
parent: Manpages
---
#Nagios check_dns Plugin

    check_dns v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 2000-2018 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin uses the nslookup program to obtain the IP address for the given host/domain query.
    An optional DNS server to use may be specified.
    If no DNS server is specified, the default server(s) specified in /etc/resolv.conf will be used.


    Usage:
    check_dns -H host [-s server] [-q type ] [-a expected-address] [-A] [-n] [-t timeout] [-w warn] [-c crit]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=HOST
        The name or address you want to query
     -s, --server=HOST
        Optional DNS server you want to use for the lookup
     -q, --querytype=TYPE
        Optional DNS record query type where TYPE =(A, AAAA, SRV, TXT, MX, ANY)
        The default query type is 'A' (IPv4 host entry)
        BIND 9.11.x onwards supports both 'A' and 'AAAA', if you want both use 'ANY'
     -a, --expected-address=IP-ADDRESS|HOST
        Optional IP-ADDRESS you expect the DNS server to return. HOST must end with
        a dot (.). This option can be repeated multiple times (Returns OK if any
        value match). If multiple addresses are returned at once, you have to match
        the whole string of addresses separated with commas (sorted alphabetically).
        If you would like to test for the presence of a cname, combine with -n param.
     -A, --expect-authority
        Optionally expect the DNS server to be authoritative for the lookup
     -n, --accept-cname
        Optionally accept cname responses as a valid result to a query
        The default is to ignore cname responses as part of the result
     -w, --warning=seconds
        Return warning if elapsed time exceeds value. Default off
     -c, --critical=seconds
        Return critical if elapsed time exceeds value. Default off
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

