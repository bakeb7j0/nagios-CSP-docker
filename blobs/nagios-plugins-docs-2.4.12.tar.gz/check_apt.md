title: check_apt
parent: Manpages
---
#Nagios check_apt Plugin

    check_apt v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2006-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin checks for software updates on systems that use
    package management systems based on the apt-get(8) command
    found in Debian GNU/Linux


    Usage:
    check_apt [[-d|-u|-U]opts] [-n] [-t timeout] [-w packages-warning]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -t, --timeout=INTEGER
        Seconds before plugin times out (default: 10)
     -U, --upgrade=OPTS
        [Default] Perform an upgrade.  If an optional OPTS argument is provided,
        apt-get will be run with these command line options instead of the
        default (-o 'Debug::NoLocking=true' -s -qq).
        Note that you may be required to have root privileges if you do not use
        the default options.
     -d, --dist-upgrade=OPTS
        Perform a dist-upgrade instead of normal upgrade. Like with -U OPTS
        can be provided to override the default options.
      -n, --no-upgrade
        Do not run the upgrade.  Probably not useful (without -u at least).
     -i, --include=REGEXP
        Include only packages matching REGEXP.  Can be specified multiple times
        the values will be combined together.  Any packages matching this list
        cause the plugin to return WARNING status.  Others will be ignored.
        Default is to include all packages.
     -e, --exclude=REGEXP
        Exclude packages matching REGEXP from the list of packages that would
        otherwise be included.  Can be specified multiple times; the values
        will be combined together.  Default is to exclude no packages.
     -c, --critical=REGEXP
        If the full package information of any of the upgradable packages match
        this REGEXP, the plugin will return CRITICAL status.  Can be specified
        multiple times like above.  Default is a regexp matching security
        upgrades for Debian and Ubuntu:
        	^[^\(]*\(.* (Debian-Security:|Ubuntu:[^/]*/[^-]*-security)
        Note that the package must first match the include list before its
        information is compared against the critical list.
     -o, --only-critical
        Only warn about upgrades matching the critical list.  The total number
        of upgrades will be printed, but any non-critical upgrades will not cause
        the plugin to return WARNING status.

     -w, --packages-warning=INTEGER
        Minumum number of packages available for upgrade to return WARNING status.
        Default is 1 package.

    The following options require root privileges and should be used with care:

     -u, --update=OPTS
        First perform an 'apt-get update'.  An optional OPTS parameter overrides
        the default options.  Note: you may also need to adjust the global
        timeout (with -t) to prevent the plugin from timing out if apt-get
        upgrade is expected to take longer than the default timeout.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

