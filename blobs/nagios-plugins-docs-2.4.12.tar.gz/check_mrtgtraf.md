title: check_mrtgtraf
parent: Manpages
---
#Nagios check_mrtgtraf Plugin

    check_mrtgtraf v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 1999-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin will check the incoming/outgoing transfer rates of a router,
    switch, etc recorded in an MRTG log.  If the newest log entry is older
    than <expire_minutes>, a WARNING status is returned. If either the
    incoming or outgoing rates exceed the <icl> or <ocl> thresholds (in
    Bytes/sec), a CRITICAL status results.  If either of the rates exceed
    the <iwl> or <owl> thresholds (in Bytes/sec), a WARNING status results.


    Usage check_mrtgtraf -F <log_file> -a <AVG | MAX> -w <warning_pair>
    -c <critical_pair> [-e expire_minutes]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -F, --filename=STRING
        File to read log from
     -e, --expires=INTEGER
        Minutes after which log expires
     -a, --aggregation=(AVG|MAX)
        Test average or maximum
     -w, --warning
        Warning threshold pair <incoming>,<outgoing>
     -c, --critical
        Critical threshold pair <incoming>,<outgoing>
     -v, --verbose
        Verbose output during plugin runtime
     -i, --interface-maximum
        Define the maximum bandwidth on the port being monitored (Bytes/sec)
        This adds percentages to performance data output

    Notes:
     - MRTG stands for Multi Router Traffic Grapher. It can be downloaded from
       http://ee-staff.ethz.ch/~oetiker/webtools/mrtg/mrtg.html
     - While MRTG can monitor things other than traffic rates, this
       plugin probably won't work with much else without modification.
     - The calculated i/o rates are a little off from what MRTG actually
       reports.  I'm not sure why this is right now, but will look into it
       for future enhancements of this plugin.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

