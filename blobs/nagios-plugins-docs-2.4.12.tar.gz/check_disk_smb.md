title: check_disk_smb
parent: Manpages
---
#Nagios check_disk_smb Plugin

    check_disk_smb v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.
    Copyright (c) 2000 Michael Anthon/Karl DeBisschop

    Perl Check SMB Disk plugin for Nagios

    Usage: check_disk_smb -H <host> -s <share> -u <user>
          -p <password> -w <warn> -c <crit> [-W <workgroup>] [-P <port>]
          [-a <IP>] [-C <configfile>]

    -H, --hostname=HOST
       NetBIOS name of the server
    -s, --share=STRING
       Share name to be tested
    -W, --workgroup=STRING
       Workgroup or Domain used (Defaults to "WORKGROUP")
    -a, --address=IP
       IP-address of HOST (only necessary if HOST is in another network)
    -u, --user=STRING
       Username to log in to server. (Defaults to "guest")
    -p, --password=STRING
       Password to log in to server. (Defaults to an empty password)
    -w, --warning=INTEGER or INTEGER[kMG]
       Percent of used space at which a warning will be generated (Default: 85%)
    -c, --critical=INTEGER or INTEGER[kMG]
       Percent of used space at which a critical will be generated (Defaults: 95%)
    -P, --port=INTEGER
       Port to be used to connect to. Some Windows boxes use 139, others 445 (Defaults to smbclient default)
    -C, --configfile=STRING
       Path to configfile which should be used by smbclient (Defaults to smb.conf of your smb installation)

       If thresholds are followed by either a k, M, or G then check to see if that
       much disk space is available (kilobytes, Megabytes, Gigabytes)

       Warning percentage should be less than critical
       Warning (remaining) disk space should be greater than critical.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org. Please include version information with all
    correspondence (when possible, use output from the --version option of the
    plugin itself).
