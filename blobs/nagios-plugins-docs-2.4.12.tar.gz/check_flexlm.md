title: check_flexlm
parent: Manpages
---
#Nagios check_flexlm Plugin

    check_flexlm v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.
    Copyright (c) 2000 Ernst-Dieter Martin/Karl DeBisschop

    Check available flexlm license managers

    Usage:
       check_flexlm -F <filename> [-v] [-t] [-V] [-h]
       check_flexlm --help
       check_flexlm --version

    -F, --filename=FILE
       Name of license file (like "/usr/local/flexlm/licenses/license.dat")
    -v, --verbose
       Print some extra debugging information (not advised for normal operation)
    -t, --timeout
       Plugin time out in seconds (default = 15 )
    -V, --version
       Show version and license information
    -h, --help
       Show this help screen

    Flexlm license managers usually run as a single server or three servers and a
    quorum is needed.  The plugin return OK if 1 (single) or 3 (triple) servers
    are running, CRITICAL if 1(single) or 3 (triple) servers are down, and WARNING
    if 1 or 2 of 3 servers are running

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org. Please include version information with all
    correspondence (when possible, use output from the --version option of the
    plugin itself).
