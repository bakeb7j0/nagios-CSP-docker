title: check_dhcp
parent: Manpages
---
#Nagios check_dhcp Plugin

    check_dhcp v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2001-2004 Ethan Galstad (nagios@nagios.org)
    Copyright (c) 2001-2018 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin tests the availability of DHCP servers on a network.


    Usage:
     check_dhcp [-v] [-u] [-s serverip] [-r requestedip] [-t timeout]
                      [-i interface] [-m mac]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)
     -s, --serverip=IPADDRESS
        IP address of DHCP server that we must hear from
     -r, --requestedip=IPADDRESS
        IP address that should be offered by at least one DHCP server
     -t, --timeout=INTEGER
        Seconds to wait for DHCPOFFER before timeout occurs
     -i, --interface=STRING
        Interface to to use for listening (i.e. eth0)
     -m, --mac=STRING
        MAC address to use in the DHCP request
     -u, --unicast
        Unicast testing: mimic a DHCP relay, requires -s

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

