title: check_mrtg
parent: Manpages
---
#Nagios check_mrtg Plugin

    check_mrtg v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 1999-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin will check either the average or maximum value of one of the
    two variables recorded in an MRTG log file.


    Usage:
    check_mrtg -F log_file -a <AVG | MAX> -v variable -w warning -c critical
    [-l label] [-u units] [-e expire_minutes] [-t timeout] [-v]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -F, --logfile=FILE
       The MRTG log file containing the data you want to monitor
     -e, --expires=MINUTES
       Minutes before MRTG data is considered to be too old
     -a, --aggregation=AVG|MAX
       Should we check average or maximum values?
     -v, --variable=INTEGER
       Which variable set should we inspect? (1 or 2)
     -w, --warning=INTEGER
       Threshold value for data to result in WARNING status
     -c, --critical=INTEGER
       Threshold value for data to result in CRITICAL status
     -l, --label=STRING
       Type label for data (Examples: Conns, "Processor Load", In, Out)
     -u, --units=STRING
       Option units label for data (Example: Packets/Sec, Errors/Sec,
       "Bytes Per Second", "%% Utilization")

     If the value exceeds the <vwl> threshold, a WARNING status is returned. If
     the value exceeds the <vcl> threshold, a CRITICAL status is returned.  If
     the data in the log file is older than <expire_minutes> old, a WARNING
     status is returned and a warning message is printed.

     This plugin is useful for monitoring MRTG data that does not correspond to
     bandwidth usage.  (Use the check_mrtgtraf plugin for monitoring bandwidth).
     It can be used to monitor any kind of data that MRTG is monitoring - errors,
     packets/sec, etc.  I use MRTG in conjunction with the Novell NLM that allows
     me to track processor utilization, user connections, drive space, etc and
     this plugin works well for monitoring that kind of data as well.

    Notes:
     - This plugin only monitors one of the two variables stored in the MRTG log
       file.  If you want to monitor both values you will have to define two
       commands with different values for the <variable> argument.  Of course,
       you can always hack the code to make this plugin work for you...
     - MRTG stands for the Multi Router Traffic Grapher.  It can be downloaded from
       http://ee-staff.ethz.ch/~oetiker/webtools/mrtg/mrtg.html

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

