title: check_pgsql
parent: Manpages
---
#Nagios check_pgsql Plugin

    check_pgsql v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    Test whether a PostgreSQL Database is accepting connections.

    Usage:
    check_pgsql [-H <host>] [-P <port>] [-c <critical time>] [-w <warning time>]
     [-t <timeout>] [-d <database>] [-l <logname>] [-p <password>]
    [-q <query>] [-C <critical query range>] [-W <warning query range>] [-r]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -P, --port=INTEGER
        Port number (default: 5432)
     -d, --database=STRING
        Database to check (default: template1)
     -l, --logname = STRING
        Login name of user
     -p, --password = STRING
        The user's password. To avoid security issues, define this option using
        --extra-opts when possible.
     -o, --option = STRING
        Connection parameters (keyword = value), see below
     -w, --warning=DOUBLE
        Response time to result in warning status (seconds)
     -c, --critical=DOUBLE
        Response time to result in critical status (seconds)
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -q, --query=STRING
        SQL query to run. Only first column in first row will be read
     -W, --query-warning=RANGE
        SQL query value to result in warning status (double)
     -C, --query-critical=RANGE
        SQL query value to result in critical status (double)
     -r,  --print-query
        Print the output of the entire query to extended plugin output.
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

     All parameters are optional.
     This plugin tests a PostgreSQL DBMS to determine whether it is active and
     accepting queries. In its current operation, it simply connects to the
     specified database, and then disconnects. If no database is specified, it
     connects to the template1 database, which is present in every functioning
     PostgreSQL DBMS.

     If a query is specified using the -q option, it will be executed after
     connecting to the server. The result from the query has to be numeric.
     Multiple SQL commands, separated by semicolon, are allowed but the result 
     of the last command is taken into account only. The value of the first
     column in the first row is used as the check result.

     See the chapter "Monitoring Database Activity" of the PostgreSQL manual
     for details about how to access internal statistics of the database server.

     For a list of available connection parameters which may be used with the -o
     command line option, see the documentation for PQconnectdb() in the chapter
     "libpq - C Library" of the PostgreSQL manual. For example, this may be
     used to specify a service name in pg_service.conf to be used for additional
     connection parameters: -o 'service=<name>' or to specify the SSL mode:
     -o 'sslmode=require'.

     The plugin will connect to a local postmaster if no host is specified. To
     connect to a remote host, be sure that the remote postmaster accepts TCP/IP
     connections (start the postmaster with the -i option).

     Typically, the nagios user (unless the --logname option is used) should be
     able to connect to the database without a password. The plugin can also send
     a password, but no effort is made to obscure or encrypt the password.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

