title: check_uptime
parent: Manpages
---
#Nagios check_uptime Plugin

    check_uptime v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin checks the system uptime and alerts if more than the threshold.
    Threshold unit of measurement specified with "-u".
    "-u" switch supports: seconds|minutes|hours|days.
    Usage:
    check_uptime [-u uom] [-w threshold] [-c threshold] [-t] [-h] [-vvv] [-V]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
    -u, Time unit of measurement (seconds|minutes|hours|days) (default: minutes)
    -w, Warning threshold
    -c, Critcal threshold
    -t, Plugin timeout, default 10 seconds
    -vvv, Enable verbose output

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

