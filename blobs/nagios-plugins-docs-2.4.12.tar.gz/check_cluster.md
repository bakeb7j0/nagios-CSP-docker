title: check_cluster
parent: Manpages
---
#Nagios check_cluster Plugin

    check_cluster v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2000-2004 Ethan Galstad (nagios@nagios.org)
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    Host/Service Cluster Plugin for Nagios 2

    Usage:
     check_cluster (-s | -h) -d val1[,val2,...,valn] [-l label]
    [-w threshold] [-c threshold] [-v] [--help]

    Options:
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -s, --service
        Check service cluster status
     -h, --host
        Check host cluster status
     -l, --label=STRING
        Optional prepended text output (i.e. "Host cluster")
     -w, --warning=THRESHOLD
        Specifies the range of hosts or services in cluster that must be in a
        non-OK state in order to return a WARNING status level
     -c, --critical=THRESHOLD
        Specifies the range of hosts or services in cluster that must be in a
        non-OK state in order to return a CRITICAL status level
     -d, --data=LIST
        The status codes of the hosts or services in the cluster, separated by
        commas
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    Notes:
     See:
     https://www.nagios-plugins.org/doc/guidelines.html#THRESHOLDFORMAT
     for THRESHOLD format and examples.

    Examples:
     check_cluster -s -d 2,0,2,0 -c @3:
        Will alert critical if there are 3 or more service data points in a non-OK
        state.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

