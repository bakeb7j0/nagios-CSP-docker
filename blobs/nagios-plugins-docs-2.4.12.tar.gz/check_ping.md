title: check_ping
parent: Manpages
---
#Nagios check_ping Plugin

    check_ping v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    Use ping to check connection statistics for a remote host.

    Usage:
    check_ping -H <host_address> -w <wrta>,<wpl>% -c <crta>,<cpl>%
     [-p packets] [-t timeout] [-4|-6]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -H, --hostname=HOST
        host to ping
     -w, --warning=THRESHOLD
        warning threshold pair
     -c, --critical=THRESHOLD
        critical threshold pair
     -p, --packets=INTEGER
        number of ICMP ECHO packets to send (Default: 5)
     -s, --show-resolution
        show name resolution in the plugin output (DNS & IP)
     -L, --link
        show HTML in the plugin output (obsoleted by urlize)
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING

    THRESHOLD is <rta>,<pl>% where <rta> is the round trip average travel
    time (ms) which triggers a WARNING or CRITICAL state, and <pl> is the
    percentage of packet loss to trigger an alarm state.

    This plugin uses the ping command to probe the specified host for packet loss
    (percentage) and round trip average (milliseconds). It can produce HTML output
    linking to a traceroute CGI contributed by Ian Cass. The CGI can be found in
    the contrib area of the downloads section at http://www.nagios.org/

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

