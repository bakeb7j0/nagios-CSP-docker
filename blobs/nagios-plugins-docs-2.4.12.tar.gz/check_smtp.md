title: check_smtp
parent: Manpages
---
#Nagios check_smtp Plugin

    check_smtp v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999-2001 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin will attempt to open an SMTP connection with the host.


    Usage:
    check_smtp -H host [-p port] [-4|-6] [-e expect] [-C command] [-R response] [-f from addr]
    [-A authtype -U authuser -P authpass] [-w warn] [-c crit] [-t timeout] [-q]
    [-F fqdn] [-S] [-L] [-D warn days cert expire[,crit days cert expire]] [--sni] [-v] 

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 25)
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -e, --expect=STRING
        String to expect in first line of server response (default: '220')
     -C, --command=STRING
        SMTP command (may be used repeatedly)
     -R, --response=STRING
        Expected response to command (may be used repeatedly)
     -f, --from=STRING
        FROM-address to include in MAIL command, required by Exchange 2000
     -F, --fqdn=STRING
        FQDN used for HELO
     -r, --proxy
        Use PROXY protocol prefix for the connection.
     -D, --certificate=INTEGER[,INTEGER]
        Minimum number of days a certificate has to be valid.
     -s, --ssl
        Use SSL/TLS for the connection.
     -S, --starttls
        Use STARTTLS for the connection.
     --sni
        Enable SSL/TLS hostname extension support (SNI)
     -A, --authtype=STRING
        SMTP AUTH type to check (default none, only LOGIN supported)
     -U, --authuser=STRING
        SMTP AUTH username
     -P, --authpass=STRING
        SMTP AUTH password
     -L, --lmtp
        Send LHLO instead of HELO/EHLO
     -q, --ignore-quit-failure
        Ignore failure when sending QUIT command to server
     -w, --warning=DOUBLE
        Response time to result in warning status (seconds)
     -c, --critical=DOUBLE
        Response time to result in critical status (seconds)
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    Successul connects return STATE_OK, refusals and timeouts return
    STATE_CRITICAL, other errors return STATE_UNKNOWN.  Successful
    connects, but incorrect response messages from the host result in
    STATE_WARNING return values.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

