title: check_file_age
parent: Manpages
---
#Nagios check_file_age Plugin

    check_file_age v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.
    Copyright (c) 2003 Steven Grimm

    Usage:
      check_file_age [-w <secs>] [-c <secs>] [-W <size>] [-C <size>] [-i] -f <file>
      check_file_age [-h | --help]
      check_file_age [-V | --version]

      -i | --ignore-missing :  return OK if the file does not exist
      <secs>  File must be no more than this many seconds old (default: warn 240 secs, crit 600)
      <size>  File must be at least this many bytes long (default: crit 0 bytes)

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org. Please include version information with all
    correspondence (when possible, use output from the --version option of the
    plugin itself).
