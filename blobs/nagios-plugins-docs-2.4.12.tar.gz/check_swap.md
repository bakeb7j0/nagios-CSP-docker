title: check_swap
parent: Manpages
---
#Nagios check_swap Plugin

    check_swap v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2000-2023 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    Check swap space on local machine.


    Usage:
     check_swap [-av] [-w <percent_free>% -c <percent_free>%]
      [-w <bytes_free> -c <bytes_free>] [-n <state>]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -w, --warning=INTEGER
        Exit with WARNING status if less than INTEGER bytes of swap space are free
     -w, --warning=PERCENT%
        Exit with WARNING status if less than PERCENT of swap space is free
     -c, --critical=INTEGER
        Exit with CRITICAL status if less than INTEGER bytes of swap space are free
     -c, --critical=PERCENT%
        Exit with CRITICAL status if less than PERCENT of swap space is free
     -a, --allswaps
        Conduct comparisons for all swap partitions, one by one
     -n, --no-swap=<ok|warning|critical|unknown>
        Resulting state when there is no swap regardless of thresholds. Default: CRITICAL
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    Notes:
     Both INTEGER and PERCENT thresholds can be specified, they are all checked.
     Without thresholds, the plugin shows free swap space and performance data, but always returns OK.
     On AIX, if -a is specified, uses lsps -a, otherwise uses lsps -s.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

