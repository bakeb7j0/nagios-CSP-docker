title: check_ssl_validity
parent: Manpages
---
#Nagios check_ssl_validity Plugin

