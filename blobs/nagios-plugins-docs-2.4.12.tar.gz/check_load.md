title: check_load
parent: Manpages
---
#Nagios check_load Plugin

    check_load v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Felipe Gustavo de Almeida <galmeida@linux.ime.usp.br>
    Copyright (c) 1999-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin tests the current system load average.

    Usage:
    check_load [-r] -w WLOAD1,WLOAD5,WLOAD15 -c CLOAD1,CLOAD5,CLOAD15 [-n NUMBER_OF_PROCS]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -w, --warning=WLOAD1,WLOAD5,WLOAD15
        Exit with WARNING status if load average exceeds WLOADn
     -c, --critical=CLOAD1,CLOAD5,CLOAD15
        Exit with CRITICAL status if load average exceed CLOADn
        the load average format is the same used by "uptime" and "w"
     -r, --percpu
        Divide the load averages by the number of CPUs (when possible)
     -n, --procs-to-show=NUMBER_OF_PROCS
        Number of processes to show when printing the top consuming processes.
        NUMBER_OF_PROCS=0 disables this feature. Default value is 0

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

