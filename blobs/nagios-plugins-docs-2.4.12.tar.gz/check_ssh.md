title: check_ssh
parent: Manpages
---
#Nagios check_ssh Plugin

    check_ssh v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Remi Paulmier <remi@sinfomic.fr>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    Try to connect to an SSH server at specified server and port


    Usage:
    check_ssh  [-4|-6] [-t <timeout>] [-r <remote version>] [-p <port>] <host>

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 22)
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -r, --remote-version=STRING
        Alert if string doesn't match expected server version (ex: OpenSSH_3.9p1)
     -P, --remote-protocol=STRING
        Alert if protocol doesn't match expected protocol version (ex: 2.0)
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

