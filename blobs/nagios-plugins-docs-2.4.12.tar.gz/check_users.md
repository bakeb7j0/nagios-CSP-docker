title: check_users
parent: Manpages
---
#Nagios check_users Plugin

    check_users v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin checks the number of users currently logged in on the local
    system and generates an error if the number exceeds the thresholds specified.


    Usage:
    check_users -w <users> -c <users>

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -w, --warning=INTEGER
        Set WARNING status if more than INTEGER users are logged in
     -c, --critical=INTEGER
        Set CRITICAL status if more than INTEGER users are logged in

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

