title: check_nagios
parent: Manpages
---
#Nagios check_nagios Plugin

    check_nagios v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin checks the status of the Nagios process on the local machine
    The plugin will check to make sure the Nagios status log is no older than
    the number of minutes specified by the expires option.
    It also checks the process table for a process matching the command argument.


    Usage:
    check_nagios -F <status log file> -t <timeout_seconds> -e <expire_minutes> -C <process_string>

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -F, --filename=FILE
        Name of the log file to check
     -e, --expires=INTEGER
        Minutes aging after which logfile is considered stale
     -C, --command=STRING
        Substring to search for in process arguments
     -t, --timeout=INTEGER
        Timeout for the plugin in seconds
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    Examples:
     check_nagios -t 20 -e 5 -F /usr/local/nagios/var/status.log -C /usr/local/nagios/bin/nagios

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

