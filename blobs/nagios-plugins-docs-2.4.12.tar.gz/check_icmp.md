title: check_icmp
parent: Manpages
---
#Nagios check_icmp Plugin

    check_icmp v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2005-2018 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    Usage:
     check_icmp [options] [-H] host1 host2 hostN

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -w
        warning threshold (currently 200.000ms,40%)
     -c
        critical threshold (currently 500.000ms,80%)
     -R
        RTA, round trip average,  mode  warning,critical, ex. 100ms,200ms unit in ms
     -P
        packet loss mode, ex. 40%,50% , unit in %
     -J
        jitter mode  warning,critical, ex. 40.000ms,50.000ms , unit in ms 
     -M
        MOS mode, between 0 and 4.4  warning,critical, ex. 3.5,3.0
     -S
        score  mode, max value 100  warning,critical, ex. 80,70 
     -O
        detect out of order ICMP packts 
     -4
        target address(es) are IPv4 and packets are ICMPv4
     -6
        target address(es) are IPv6 and packets are ICMPv6
     -H
        specify a target
     -s
        specify a source IP address or device name
     -n
        number of packets to send (currently 5)
     -p
        number of packets to send (currently 5)
     -i
        max packet interval (currently 80.000ms)
     -I
        max target interval (currently 0.000ms)
     -m
        number of alive hosts required for success
     -l
        TTL on outgoing packets (currently 0)
     -t
        timeout value (seconds, currently  10)
     -b
        Number of icmp data bytes to send
        Packet size will be data bytes + icmp header (currently 68 + 8)
     -f
        separator for perfdata instance
     -F
        number of instances to output perfdata for
     -v
        verbose

    Notes:
     If not mode R,P,J,M,S or O is informed, default icmp behavior, RTA and packet loss

     The -H switch is optional. Naming a host (or several) to check is not.

     When defining multiple addresses they must be provided as the last argument.

     Threshold format for -w and -c is 200.25,60% for 200.25 msec RTA and 60%
     packet loss.  The default values should work well for most users.
     You can specify different RTA factors using the standardized abbreviations
     us (microseconds), ms (milliseconds, default) or just plain s for seconds.

     The -v switch can be specified several times for increased verbosity.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

