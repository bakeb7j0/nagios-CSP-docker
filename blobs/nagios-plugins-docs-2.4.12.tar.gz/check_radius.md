title: check_radius
parent: Manpages
---
#Nagios check_radius Plugin

