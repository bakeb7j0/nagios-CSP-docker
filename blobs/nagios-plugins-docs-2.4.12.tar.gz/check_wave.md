title: check_wave
parent: Manpages
---
#Nagios check_wave Plugin

    /usr/local/nagios/libexec/check_wave v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.
    Copyright (c) 2000 Jeffery Blank/Karl DeBisschop

    Usage: /usr/local/nagios/libexec/check_wave -H <host> [-w <warn>] [-c <crit>]

    <warn> = Signal strength at which a warning message will be generated.
    <crit> = Signal strength at which a critical message will be generated.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org. Please include version information with all
    correspondence (when possible, use output from the --version option of the
    plugin itself).
