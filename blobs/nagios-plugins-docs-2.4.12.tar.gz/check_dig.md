title: check_dig
parent: Manpages
---
#Nagios check_dig Plugin

    check_dig v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2000 Karl DeBisschop <kdebisschop@users.sourceforge.net>
    Copyright (c) 2002-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin test the DNS service on the specified host using dig

    Usage:
    check_dig -l <query_address> [-H <host>] [-p <server port>]
     [-T <query type>] [-w <warning interval>] [-c <critical interval>]
     [-t <timeout>] [-r <retries>] [-a <expected answer address>] [-v]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 53)
     -4, --use-ipv4
        Force dig to only use IPv4 query transport
     -6, --use-ipv6
        Force dig to only use IPv6 query transport
     -l, --query_address=STRING
        Machine name to lookup
     -T, --record_type=STRING
        Record type to lookup (default: A)
     -a, --expected_address=STRING
        An address expected to be in the answer section. If not set, uses whatever
        was in -l
     -A, --dig-arguments=STRING
        Pass STRING as argument(s) to dig
     -r, --retries=INTEGER
        Number of retries passed to dig, timeout is divided by this value (Default: 3)
     -e, --exact
        Match records exactly. If not set, fuzzy matches.
     -w, --warning=DOUBLE
        Response time to result in warning status (seconds)
     -c, --critical=DOUBLE
        Response time to result in critical status (seconds)
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    Examples:
     check_dig -H DNSSERVER -l www.example.com -A "+tcp"
     This will send a tcp query to DNSSERVER for www.example.com

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

