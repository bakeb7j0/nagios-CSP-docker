title: check_mysql
parent: Manpages
---
#Nagios check_mysql Plugin

    check_mysql v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This program tests connections to a MySQL server


    Usage:
     check_mysql [-d database] [-H host] [-P port] [-s socket]
           [-u user] [-p password] [-S] [-l] [-a cert] [-k key]
           [-C ca-cert] [-D ca-dir] [-L ciphers] [-f optfile] [-g group]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -P, --port=INTEGER
        Port number (default: 3306)
     -n, --ignore-auth
        Ignore authentication failure and check for mysql connectivity only
     -s, --socket=STRING
        Use the specified socket (has no effect if -H is used)
     -d, --database=STRING
        Check database with indicated name
     -f, --file=STRING
        Read from the specified client options file
     -g, --group=STRING
        Use a client options group
     -u, --username=STRING
        Connect using the indicated username
     -p, --password=STRING
        Use the indicated password to authenticate the connection
        ==> IMPORTANT: THIS FORM OF AUTHENTICATION IS NOT SECURE!!! <==
        Your clear-text password could be visible as a process table entry
     -S, --check-slave
        Check if the slave thread is running properly.
     -w, --warning
        Exit with WARNING status if slave server is more than INTEGER seconds
        behind master
     -c, --critical
        Exit with CRITICAL status if slave server is more then INTEGER seconds
        behind master
     -l, --ssl
        Use ssl encryptation
     -C, --ca-cert=STRING
        Path to CA signing the cert
     -a, --cert=STRING
        Path to SSL certificate
     -k, --key=STRING
        Path to private SSL key
     -D, --ca-dir=STRING
        Path to CA directory
     -L, --ciphers=STRING
        List of valid SSL ciphers

     There are no required arguments. By default, the local database is checked
     using the default unix socket. You can force TCP on localhost by using an
     IP address or FQDN ('localhost' will use the socket as well).

    Notes:
     You must specify -p with an empty string to force an empty password,
     overriding any my.cnf settings.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

