title: check_ide_smart
parent: Manpages
---
#Nagios check_ide_smart Plugin

    check_ide_smart v2.4.12 (nagios-plugins 2.4.12)
    Nagios feature - 1999 Robert Dale <rdale@digital-mission.com>
    (C) 1999 Ragnar Hojland Espinosa <ragnar@lightside.dhis.org>
    Copyright (c) 1998-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin checks a local hard drive with the (Linux specific) SMART interface [http://smartlinux.sourceforge.net/smart/index.php].

    Usage:
    check_ide_smart [-d <device>] [-i <immediate>] [-q quiet] [-1 <auto-on>] [-O <auto-off>] [-n <nagios>]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -d, --device=DEVICE
        Select device DEVICE
        Note: if the device is selected with this option, _no_ other options are accepted
     -i, --immediate
        Perform immediately offline tests
     -q, --quiet-check
        Returns the number of failed tests
     -1, --auto-on
        Turn on automatic offline tests
     -0, --auto-off
        Turn off automatic offline tests
     -n, --nagios
        Output suitable for Nagios

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

