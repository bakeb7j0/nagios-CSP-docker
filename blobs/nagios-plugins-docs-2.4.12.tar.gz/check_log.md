title: check_log
parent: Manpages
---
#Nagios check_log Plugin

    check_log v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.

    Usage: check_log -F logfile -O oldlog -q query
    Usage: check_log --help
    Usage: check_log --version
         Additional parameter:
            -w (--max_warning) If used, determines the maximum matching value to return
             as warning, when finding more matching lines than this parameter will
             return as critical. If not used, will consider as default 0 (any matching
             will consider as critical)
    Usage: check_log -F logfile -O oldlog -q query -w <number>

    Log file pattern detector plugin for Nagios

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org. Please include version information with all
    correspondence (when possible, use output from the --version option of the
    plugin itself).
