title: check_hpjd
parent: Manpages
---
#Nagios check_hpjd Plugin

    check_hpjd v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin tests the STATUS of an HP printer with a JetDirect card.
    Net-snmp must be installed on the computer running the plugin.


    Usage:
    check_hpjd -H host [-C community] [-p port][-N]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -C, --community=STRING
        The SNMP community name (default=public)
     -p, --port=STRING
        Specify the port to check (default=161)
     -N, --flawcorrection
        Correct false offline status reports (default=false)

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

