title: check_dbi
parent: Manpages
---
#Nagios check_dbi Plugin

    check_dbi v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This program connects to an (SQL) database using DBI and checks the
    specified metric against threshold levels. The default metric is
    the result of the specified query.


    Usage:
    check_dbi -d <DBI driver> [-o <DBI driver option> [...]] [-q <query>]
     [-H <host>] [-c <critical range>] [-w <warning range>] [-m <metric>]
     [-e <string>] [-r|-R <regex>]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.

     -d, --driver=STRING
        DBI driver to use
     -o, --option=STRING
        DBI driver options
     -q, --query=STRING
        query to execute

     -w, --warning=RANGE
        Warning range (format: start:end). Alert if outside this range
     -c, --critical=RANGE
        Critical range
     -e, --expect=STRING
        String to expect as query result
        Do not mix with -w, -c, -r, or -R!
     -r, --regex=REGEX
        Extended POSIX regular expression to check query result against
        Do not mix with -w, -c, -e, or -R!
     -R, --regexi=REGEX
        Case-insensitive extended POSIX regex to check query result against
        Do not mix with -w, -c, -e, or -r!
     -m, --metric=METRIC
        Metric to check thresholds against. Available metrics:
        CONN_TIME    - time used for setting up the database connection
        QUERY_RESULT - result (first column of first row) of the query
        QUERY_TIME   - time used to execute the query
                       (ignore the query result)

     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

     A DBI driver (-d option) is required. If the specified metric operates
     on a query, one has to be specified (-q option).

     This plugin connects to an (SQL) database using libdbi and, optionally,
     executes the specified query. The first column of the first row of the
     result will be parsed and, in QUERY_RESULT mode, compared with the
     warning and critical ranges. The result from the query has to be numeric
     (strings representing numbers are fine).

     The number and type of required DBI driver options depends on the actual
     driver. See its documentation at http://libdbi-drivers.sourceforge.net/
     for details.

     Examples:
      check_dbi -d pgsql -o username=postgres -m QUERY_RESULT \
        -q 'SELECT COUNT(*) FROM pg_stat_activity' -w 5 -c 10
      Warning if more than five connections; critical if more than ten.

      check_dbi -d mysql -H localhost -o username=user -o password=secret \
        -q 'SELECT COUNT(*) FROM logged_in_users -w 5:20 -c 0:50
      Warning if less than 5 or more than 20 users are logged in; critical
      if more than 50 users.

      check_dbi -d firebird -o username=user -o password=secret -o dbname=foo \
        -m CONN_TIME -w 0.5 -c 2
      Warning if connecting to the database takes more than half of a second;
      critical if it takes more than 2 seconds.

      check_dbi -d mysql -H localhost -o username=user \
        -q 'SELECT concat(@@version, " ", @@version_comment)' \
        -r '^5\.[01].*MySQL Enterprise Server'
      Critical if the database server is not a MySQL enterprise server in either
      version 5.0.x or 5.1.x.

      check_dbi -d pgsql -u username=user -m SERVER_VERSION \
        -w 090000:090099 -c 090000:090199
      Warn if the PostgreSQL server version is not 9.0.x; critical if the version
      is less than 9.x or higher than 9.1.x.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

