title: check_ntp_time
parent: Manpages
---
#Nagios check_ntp_time Plugin

    check_ntp_time v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2006 Sean Finney
    Copyright (c) 2006-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin checks the clock offset with the ntp server


    Usage:
     check_ntp_time -H <host> [-4|-6] [-w <warn>] [-c <crit>] [-v verbose] [-o <time offset>] [-d <delay>] [-W <stratum warn>] [-C <stratum crit>]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 123)
     -q, --quiet
        Returns UNKNOWN instead of CRITICAL if offset cannot be found
     -w, --warning=THRESHOLD
        Offset to result in warning status (seconds)
     -c, --critical=THRESHOLD
        Offset to result in critical status (seconds)
     -o, --time_offset=INTEGER
        Expected offset of the ntp server relative to local server (seconds)
     -d, --delay=INTEGER
        Delay between each packet (seconds)
     -W, --stratum-warn=INTEGER
        Alert warning if stratum is worse (less) than specfied value
     -C, --stratum-crit=INTEGER
        Alert critical if stratum is worse (less) than specfied value
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    This plugin checks the clock offset between the local host and a
    remote NTP server. It is independent of any commandline programs or
    external libraries.

    Notes:
     If you'd rather want to monitor an NTP server, please use
     check_ntp_peer.
     --time-offset is useful for compensating for servers with known
     and expected clock skew.
     --delay is useful if you are triggering the anti-DOS for the
     NTP server and need to leave a bigger gap between queries

     See:
     https://www.nagios-plugins.org/doc/guidelines.html#THRESHOLDFORMAT
     for THRESHOLD format and examples.

    Examples:
      ./check_ntp_time -H ntpserv -w 0.5 -c 1

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

