title: check_snmp
parent: Manpages
---
#Nagios check_snmp Plugin

    check_snmp v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999-2018 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    Check status of remote machines and obtain system information via SNMP


    Usage:
    check_snmp -H <ip_address> -o <OID> [-w warn_range] [-c crit_range]
    [-C community] [-s string] [-r regex] [-R regexi] [-t timeout] [-e retries]
    [-l label] [-u units] [-p port-number] [-d delimiter] [-D output-delimiter]
    [-m miblist] [-P snmp version] [-N context] [-L seclevel] [-U secname]
    [-a authproto] [-A authpasswd] [-x privproto] [-X privpasswd] [--strict]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -4, --use-ipv4
        Use IPv4 connection
     -6, --use-ipv6
        Use IPv6 connection
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 161)
     -n, --next
        Use SNMP GETNEXT instead of SNMP GET
     -P, --protocol=[1|2c|3]
        SNMP protocol version
     -N, --context=CONTEXT
        SNMPv3 context
     -L, --seclevel=[noAuthNoPriv|authNoPriv|authPriv]
        SNMPv3 securityLevel
     -a, --authproto=[MD5|SHA]
        SNMPv3 auth proto
     -x, --privproto=[DES|AES]
        SNMPv3 priv proto (default DES)
     -C, --community=STRING
        Optional community string for SNMP communication (default is "public")
     -U, --secname=USERNAME
        SNMPv3 username
     -A, --authpasswd=PASSWORD
        SNMPv3 authentication password
     -X, --privpasswd=PASSWORD
        SNMPv3 privacy password
     -o, --oid=OID(s)
        Object identifier(s) or SNMP variables whose value you wish to query
     -m, --miblist=STRING
        List of MIBS to be loaded (default = none if using numeric OIDs or 'ALL'
        for symbolic OIDs.)
     -d, --delimiter=STRING
        Delimiter to use when parsing returned data. Default is "="
        Any data on the right hand side of the delimiter is considered
        to be the data that should be used in the evaluation.
     -w, --warning=THRESHOLD(s)
        Warning threshold range(s)
     -c, --critical=THRESHOLD(s)
        Critical threshold range(s)
     --rate
        Enable rate calculation. See 'Rate Calculation' below
     --rate-multiplier
        Converts rate per second. For example, set to 60 to convert to per minute
     --offset=OFFSET
        Add/subtract the specified OFFSET to numeric sensor data
     --multiplier=MULTIPLIER
        Multiply the numeric sensor data by MULTIPLIER before doing comparisons
     -s, --string=STRING
        Return OK state (for that OID) if STRING is an exact match
     -r, --ereg=REGEX
        Return OK state (for that OID) if extended regular expression REGEX matches
     -R, --eregi=REGEX
        Return OK state (for that OID) if case-insensitive extended REGEX matches
     --invert-search
        Invert search result (CRITICAL if found)
     -l, --label=STRING
        Prefix label for output from plugin
     -u, --units=STRING
        Units label(s) for output data (e.g., 'sec.').
     -D, --output-delimiter=STRING
        Separates output on multiple OID requests
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -e, --retries=INTEGER
        Number of retries to be used in the requests
     -O, --perf-oids
        Label performance data with OIDs instead of --label's
     --strict
        Enable strict mode: arguments to -o will be checked against the OID
        returned by snmpget. If they don't match, the plugin returns UNKNOWN.
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    This plugin uses the 'snmpget' command included with the NET-SNMP package.
    if you don't have the package installed, you will need to download it from
    http://net-snmp.sourceforge.net before you can use this plugin.

    Notes:
     - Multiple OIDs (and labels) may be indicated by a comma or space-delimited  
       list (lists with internal spaces must be quoted).
     - See:
     https://www.nagios-plugins.org/doc/guidelines.html#THRESHOLDFORMAT
     for THRESHOLD format and examples.
     - When checking multiple OIDs, separate ranges by commas like '-w 1:10,1:,:20'
     - Note that only one string and one regex may be checked at present
     - All evaluation methods other than PR, STR, and SUBSTR expect that the value
       returned from the SNMP query is an unsigned integer.

    Rate Calculation:
     In many places, SNMP returns counters that are only meaningful when
     calculating the counter difference since the last check. check_snmp
     saves the last state information in a file so that the rate per second
     can be calculated. Use the --rate option to save state information.
     On the first run, there will be no prior state - this will return with OK.
     The state is uniquely determined by the arguments to the plugin, so
     changing the arguments will create a new state file.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

