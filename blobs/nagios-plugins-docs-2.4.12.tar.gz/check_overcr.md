title: check_overcr
parent: Manpages
---
#Nagios check_overcr Plugin

    check_overcr v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad <nagios@nagios.org>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin attempts to contact the Over-CR collector daemon running on the
    remote UNIX server in order to gather the requested system information.


    Usage:
    check_overcr -H host [-p port] [-v variable] [-w warning] [-c critical] [-t timeout]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 2000)
     -w, --warning=INTEGER
        Threshold which will result in a warning status
     -c, --critical=INTEGER
        Threshold which will result in a critical status
     -v, --variable=STRING
        Variable to check.  Valid variables include:
        LOAD1         = 1 minute average CPU load
        LOAD5         = 5 minute average CPU load
        LOAD15        = 15 minute average CPU load
        DPU<filesys>  = percent used disk space on filesystem <filesys>
        PROC<process> = number of running processes with name <process>
        NET<port>     = number of active connections on TCP port <port>
        UPTIME        = system uptime in seconds
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING
     -v, --verbose
        Show details for command-line debugging (Nagios may truncate output)

    This plugin requires that Eric Molitors' Over-CR collector daemon be
    running on the remote server.
    Over-CR can be downloaded from http://www.molitor.org/overcr
    This plugin was tested with version 0.99.53 of the Over-CR collector

    Notes:
     For the available options, the critical threshold value should always be
     higher than the warning threshold value, EXCEPT with the uptime variable

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

