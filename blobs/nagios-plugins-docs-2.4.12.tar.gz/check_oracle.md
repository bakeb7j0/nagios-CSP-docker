title: check_oracle
parent: Manpages
---
#Nagios check_oracle Plugin

    check_oracle v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.

    Usage:
      check_oracle --tns <Oracle Sid or Hostname/IP address>
      check_oracle --db <ORACLE_SID>
      check_oracle --login <ORACLE_SID>
      check_oracle --connect <ORACLE_SID>
      check_oracle --cache <ORACLE_SID> <USER> <PASS> <CRITICAL> <WARNING>
      check_oracle --tablespace <ORACLE_SID> <USER> <PASS> <TABLESPACE> <CRITICAL> <WARNING>
      check_oracle --oranames <Hostname>
      check_oracle --help
      check_oracle --version

    Check Oracle status

    --tns SID/IP Address
       Check remote TNS server
    --db SID
       Check local database (search /bin/ps for PMON process) and check
       filesystem for sgadefORACLE_SID.dbf
    --login SID
       Attempt a dummy login and alert if not ORA-01017: invalid username/password
    --connect SID
       Attempt a login and alert if an ORA- error is returned
    --cache
       Check local database for library and buffer cache hit ratios
           --->  Requires Oracle user/password and SID specified.
           		--->  Requires select on v_ and v_
    --tablespace
       Check local database for tablespace capacity in ORACLE_SID
           --->  Requires Oracle user/password specified.
           		--->  Requires select on dba_data_files and dba_free_space
    --oranames Hostname
       Check remote Oracle Names server
    --help
       Print this help screen
    --version
       Print version and license information

    If the plugin doesn't work, check that the ORACLE_HOME environment
    variable is set, that ORACLE_HOME/bin is in your PATH, and the
    tnsnames.ora file is locatable and is properly configured.

    When checking local database status your ORACLE_SID is case sensitive.

    If you want to use a default Oracle home, add in your oratab file:
    *:/opt/app/oracle/product/7.3.4:N

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org. Please include version information with all
    correspondence (when possible, use output from the --version option of the
    plugin itself).
