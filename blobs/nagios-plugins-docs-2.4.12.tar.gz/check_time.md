title: check_time
parent: Manpages
---
#Nagios check_time Plugin

    check_time v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999 Ethan Galstad
    Copyright (c) 1999-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin will check the time on the specified host.


    Usage:
    check_time -H <host_address> [-p port] [-u] [-w variance] [-c variance]
     [-W connect_time] [-C connect_time] [-t timeout]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 37)
     -u, --udp
       Use UDP to connect, not TCP
     -w, --warning-variance=INTEGER
       Time difference (sec.) necessary to result in a warning status
     -c, --critical-variance=INTEGER
       Time difference (sec.) necessary to result in a critical status
     -W, --warning-connect=INTEGER
       Response time (sec.) necessary to result in warning status
     -C, --critical-connect=INTEGER
       Response time (sec.) necessary to result in critical status
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

