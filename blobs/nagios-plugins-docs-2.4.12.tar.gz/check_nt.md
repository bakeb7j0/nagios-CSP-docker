title: check_nt
parent: Manpages
---
#Nagios check_nt Plugin

    check_nt v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2000 Yves Rubin (rubiyz@yahoo.com)
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin collects data from the NSClient service running on a
    Windows NT/2000/XP/2003 server.


    Usage:
    check_nt -H host -v variable [-p port] [-w warning] [-c critical]
    [-l params] [-d SHOWALL] [-u](DEPRECATED) [-t timeout]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
    Options:
     -H, --hostname=HOST
       Name of the host to check
     -p, --port=INTEGER
       Optional port number (default: 1248)
     -s, --secret=<password>
       Password needed for the request
     -w, --warning=INTEGER
       Threshold which will result in a warning status
     -c, --critical=INTEGER
       Threshold which will result in a critical status
     -t, --timeout=INTEGER
       Seconds before connection attempt times out (default:  -l, --params=<parameters>
       Parameters passed to specified check (see below) -d, --display={SHOWALL}
       Display options (currently only SHOWALL works) -u, --unknown-timeout  (DEPRECATED)
       Return UNKNOWN on timeouts10)
     -h, --help
       Print this help screen
     -V, --version
       Print version information
     -v, --variable=STRING
       Variable to check

    Valid variables are:
     CLIENTVERSION = Get the NSClient version
      If -l <version> is specified, will return warning if versions differ.
     CPULOAD =
      Average CPU load on last x minutes.
      Request a -l parameter with the following syntax:
      -l <minutes range>,<warning threshold>,<critical threshold>.
      <minute range> should be less than 24*60.
      Thresholds are percentage and up to 10 requests can be done in one shot.
      ie: -l 60,90,95,120,90,95
     UPTIME =
      Get the uptime of the machine.
      -l <unit> 
      <unit> = seconds, minutes, hours, or days. (default: minutes)
      Thresholds will use the unit specified above.
     USEDDISKSPACE =
      Size and percentage of disk use.
      Request a -l parameter containing the drive letter only.
      Warning and critical thresholds can be specified with -w and -c.
     MEMUSE =
      Memory use.
      Warning and critical thresholds can be specified with -w and -c.
     SERVICESTATE =
      Check the state of one or several services.
      Request a -l parameters with the following syntax:
      -l <service1>,<service2>,<service3>,...
      You can specify -d SHOWALL in case you want to see working services
      in the returned string.
     PROCSTATE =
      Check if one or several process are running.
      Same syntax as SERVICESTATE.
     COUNTER =
      Check any performance counter of Windows NT/2000.
    	Request a -l parameters with the following syntax:
    	-l "\\<performance object>\\counter","<description>
    	The <description> parameter is optional and is given to a printf 
      output command which requires a float parameter.
      If <description> does not include "%%", it is used as a label.
      Some examples:
      "Paging file usage is %%.2f %%%%"
      "%%.f %%%% paging file used."
     INSTANCES =
      Check any performance counter object of Windows NT/2000.
      Syntax: check_nt -H <hostname> -p <port> -v INSTANCES -l <counter object>
      <counter object> is a Windows Perfmon Counter object (eg. Process),
      if it is two words, it should be enclosed in quotes
      The returned results will be a comma-separated list of instances on 
       the selected computer for that object.
      The purpose of this is to be run from command line to determine what instances
       are available for monitoring without having to log onto the Windows server
        to run Perfmon directly.
      It can also be used in scripts that automatically create Nagios service
       configuration files.
      Some examples:
      check_nt -H 192.168.1.1 -p 1248 -v INSTANCES -l Process

    Notes:
     - The NSClient service should be running on the server to get any information
       (http://nsclient.ready2run.nl).
     - Critical thresholds should be lower than warning thresholds
     - Default port 1248 is sometimes in use by other services. The error
       output when this happens contains "Cannot map xxxxx to protocol number".
       One fix for this is to change the port to something else on check_nt 
       and on the client service it's connecting to.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

