title: check_rpc
parent: Manpages
---
#Nagios check_rpc Plugin

    check_rpc v2.4.12 (nagios-plugins 2.4.12)
    The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute
    copies of the plugins under the terms of the GNU General Public License.
    For more information about these matters, see the file named COPYING.
    Copyright (c) 2002 Karl DeBisschop/Truongchinh Nguyen/Subhendu Ghosh

    Check if a rpc service is registered and running using
          rpcinfo -H host -C rpc_command 

    Usage: 
     check_rpc -H host -C rpc_command [-p port] [-c program_version] [-u|-t] [-v]
     check_rpc [-h | --help]
     check_rpc [-V | --version]

      <host>          The server providing the rpc service
      <rpc_command>   The program name (or number).
      <program_version> The version you want to check for (one or more)
                        Should prevent checks of unknown versions being syslogged
                        e.g. 2,3,6 to check v2, v3, and v6
      [-u | -t]       Test UDP or TCP
      [-v]            Verbose 
      [-v -v]         Verbose - will print supported programs and numbers 

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org. Please include version information with all
    correspondence (when possible, use output from the --version option of the
    plugin itself).
