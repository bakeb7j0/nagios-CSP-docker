title: urlize
parent: Manpages
---
#Nagios urlize Plugin

    urlize v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2000 Karl DeBisschop <kdebisschop@users.sourceforge.net>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin wraps the text output of another command (plugin)
    in HTML <A> tags, thus displaying the child plugin's output as a clickable link in
    the Nagios status screen.  This plugin returns the status of the invoked plugin.


    Usage:
    urlize <url> <plugin> <arg1> ... <argN>

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information

    Examples:
    Pay close attention to quoting to ensure that the shell passes the expected
    data to the plugin. For example, in:

     urlize http://example.com/ check_http -H example.com -r 'two words'

        the shell will remove the single quotes and urlize will see:
     urlize http://example.com/ check_http -H example.com -r two words

        You probably want:

     urlize http://example.com/ "check_http -H example.com -r 'two words'"

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

