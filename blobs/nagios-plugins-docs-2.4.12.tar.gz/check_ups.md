title: check_ups
parent: Manpages
---
#Nagios check_ups Plugin

    check_ups v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 2000 Tom Shields
    Copyright (c) 2004 Alain Richard <alain.richard@equation.fr>
    Copyright (c) 2004 Arnaud Quette <arnaud.quette@mgeups.com>
    Copyright (c) 2000-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This plugin tests the UPS service on the specified host. Network UPS Tools
    from www.networkupstools.org must be running for this plugin to work.


    Usage:
    check_ups -H host -u ups [-p port] [-v variable] [-w warn_value] [-c crit_value] [-e] [-to to_sec] [-T]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -p, --port=INTEGER
        Port number (default: 3493)
     -u, --ups=STRING
        Name of UPS
     -T, --temperature
        Output of temperatures in Celsius
     -e, --extended-units
        Allow nonstandard units in performance data (used for voltage and temperatures)
     -v, --variable=STRING
        Valid values for STRING are LINE, TEMP, BATTLEFT, BATTPCT or LOADPCT
     -w, --warning=DOUBLE
        Response time to result in warning status (seconds)
     -c, --critical=DOUBLE
        Response time to result in critical status (seconds)
     -t, --timeout=INTEGER:<timeout state>
        Seconds before connection times out (default: 10)
        Optional ":<timeout state>" can be a state integer (0,1,2,3) or a state STRING

    This plugin attempts to determine the status of a UPS (Uninterruptible Power
    Supply) on a local or remote host. If the UPS is online or calibrating, the
    plugin will return an OK state. If the battery is on it will return a WARNING
    state. If the UPS is off or has a low battery the plugin will return a CRITICAL
    state.

    Notes:
     You may also specify a variable to check (such as temperature, utility voltage,
     battery load, etc.) as well as warning and critical thresholds for the value
     of that variable.  If the remote host has multiple UPS that are being monitored
     you will have to use the --ups option to specify which UPS to check.

     This plugin requires that the UPSD daemon distributed with Russell Kroll's
     Network UPS Tools be installed on the remote host. If you do not have the
     package installed on your system, you can download it from
     http://www.networkupstools.org

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

