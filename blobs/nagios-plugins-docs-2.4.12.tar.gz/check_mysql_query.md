title: check_mysql_query
parent: Manpages
---
#Nagios check_mysql_query Plugin

    check_mysql_query v2.4.12 (nagios-plugins 2.4.12)
    Copyright (c) 1999-2014 Nagios Plugin Development Team
    	<devel@nagios-plugins.org>

    This program checks a query result against threshold levels


    Usage:
     check_mysql_query -q SQL_query [-w warn] [-c crit] [-H host] [-P port] [-s socket]
           [-d database] [-u user] [-p password] [-f optfile] [-g group] [-a character-set]

    Options:
     -h, --help
        Print detailed help screen
     -V, --version
        Print version information
     --extra-opts=[section][@file]
        Read options from an ini file. See
        https://www.nagios-plugins.org/doc/extra-opts.html
        for usage and examples.
     -q, --query=STRING
        SQL query to run. Only first column in first row will be read
     -w, --warning=RANGE
        Warning range (format: start:end). Alert if outside this range
     -c, --critical=RANGE
        Critical range
     -H, --hostname=ADDRESS
        Host name, IP Address, or unix socket (must be an absolute path)
     -P, --port=INTEGER
        Port number (default: 3306)
     -s, --socket=STRING
        Use the specified socket (has no effect if -H is used)
     -d, --database=STRING
        Database to check
     -a, --character-set=STRING
        Use a specific character set when querying, e.g. latin1 or utf8
     -f, --file=STRING
        Read from the specified client options file
     -g, --group=STRING
        Use a client options group
     -u, --username=STRING
        Username to login with
     -p, --password=STRING
        Password to login with
        ==> IMPORTANT: THIS FORM OF AUTHENTICATION IS NOT SECURE!!! <==
        Your clear-text password could be visible as a process table entry

     A query is required. The result from the query should be numeric.
     For extra security, create a user with minimal access.

    Notes:
     You must specify -p with an empty string to force an empty password,
     overriding any my.cnf settings.

    Send email to help@nagios-plugins.org if you have questions regarding use
    of this software. To submit patches or suggest improvements, send email to
    devel@nagios-plugins.org

