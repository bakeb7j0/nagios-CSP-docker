-- BEGIN 2.1.2 MODS 

ALTER TABLE `nagios_scheduleddowntime` MODIFY COLUMN `duration` int NOT NULL default '0';

-- --------------------------------------------------------

--

-- END 2.1.2 MODS 

